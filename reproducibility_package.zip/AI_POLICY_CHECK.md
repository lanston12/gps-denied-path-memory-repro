# AI use disclosure and remaining author action

## Actual use confirmed by the author - 2026-09-28

The author confirmed that AI was primarily used for language polishing and formatting, and that Fig. 1 was generated using ChatGPT's web interface. The main manuscript now contains an Acknowledgment identifying OpenAI Codex for language, formatting, and consistency assistance in the manuscript/supplement, and ChatGPT (OpenAI, web interface) for the overall framework illustration in Fig. 1. It assigns responsibility for scientific content, derivations, results, figures, and references to the authors. It does not falsely state that every author has already completed personal verification.

## Policy context

The [IEEE Author Center policy](https://journals.ieeeauthorcenter.ieee.org/become-an-ieee-journal-author/publishing-ethics/guidelines-and-policies/submission-and-peer-review-policies/) requires AI-generated content to be disclosed in Acknowledgments with the system, affected content, and nature of use identified. Its scope includes figures/images/code; ordinary language editing disclosure is recommended.

The [TVT-specific author instructions](https://vtsociety.org/publication/ieee-transactions-vehicular-technology/guidelines-authors/instructions), checked on 2026-09-28, are stricter: AI cannot replace an author in generating article content, and permitted editing of author-written material must be disclosed. The inserted disclosure records actual use; it does not establish that an AI-generated illustration automatically satisfies TVT's stricter content rule. Authors must verify this point before submission, including whether the illustration is an acceptable rendering of their own framework.

## Remaining author action

The disclosure is no longer missing. Authors must verify its complete scope, the accuracy of Fig. 1, all scientific statements and references, and journal-specific acceptability. Author names/order, affiliations, corresponding author, emails, ORCIDs, funding, and other declarations remain unresolved. No portal submission has occurred.
