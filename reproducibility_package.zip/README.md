# Self-contained integrated TVT paper

Start with `main.pdf`, `submission_readiness.md` and `submission_audit.md`. There is no separate supplement. Read `integration_decision.md` and `supplement_integration_audit.md` for the selective integration, `REPRODUCE.md` for code/data verification, and the remaining focused audits for structure, wording, appendices, symbols and layout. Final current audit records supersede historical JSON copied with the data package.
