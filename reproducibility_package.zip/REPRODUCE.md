# Integrated paper reproduction and traceability

## Current verification (no new simulation)

Run from this directory:

1. `latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex`.
2. `python scripts/verify_v3.py`.
3. `python scripts/verify_tvt.py`.
4. `python scripts/verify_final_audit.py`.
5. `python scripts/verify_integrated.py`.

There is one submission PDF. Do not compile a supplementary PDF. The first verifier recomputes stored cross-model and 13,440 estimator intervals, implementation consistency and dynamics record checks. The second checks paired-seed results, citations and the single PDF. The third checks exact normalized primitives, 3/4-hop metric starts, metadata, source immutability and Results-before-Conclusion layout. The fourth checks the integrated structure, exact AI disclosure, appendix formulas/self-containment, figure citations and final page geometry.

The previous verifier scripts are retained as historical source under `reproducibility/legacy_verification`; run the migrated scripts above for this version. No numerical acceptance thresholds were loosened to accommodate editorial changes.

## Package contents

`reproducibility_package.zip` bundles the current LaTeX source/assets, all scientific data and source code, raw table sources, verification scripts, and audit/reproduction instructions. It contains no separate supplementary manuscript/PDF. Root audit CSVs and older JSON are historical provenance; current integrated audit documents/JSON supersede their presentation claims.

The 2026-09-29 reference revision also requires `bibliography_control.bib`; it supplies IEEEtran's repeated-author display setting and does not add a numbered reference. The archive includes this file. Latest reference/PDF checks are recorded in `reference_recheck_20260929.md` and `data/reference_recheck_metadata_20260929.json`. The earlier frozen directory named by the provenance manifest is currently absent, so verifiers 4 and 5 above cannot complete their external-source checks until that original directory is available; their conditions have been retained. Verifiers 2 and 3 pass on the current paper and stored records.

All CSVs, per-seed records and metadata are in `data/`; scientific Python code in `scripts/`; MATLAB/Simulink sources in their matching directories; full ordered-pair, ten-hop, preview and dynamic table source in `tables/`. `reproducibility/headline_summary.tex` preserves removed Table III for traceability. `data/integration_source_manifest.json` describes the latest immutable source directory; checks verify its 202 stored file hashes and unchanged inherited scientific code/CSV/figure assets. The framework image is byte-identical to the author-supplied graphic.

Baseline covariance increments, secondary peaks and timings remain in these records/code and are not required to understand the core theorem. The package is included locally; no public DOI/repository URL is claimed.

Software: Python 3 with NumPy/SciPy/pandas/Matplotlib, MATLAB R2022b, TeX Live 2026/IEEEtran. Scientific commands below preserve the frozen recipe; none was executed during consolidation. They reproduce existing evidence only and may overwrite package records if deliberately rerun.

## Optional regeneration of existing scientific records

The commands below document provenance; none was run to create new experiments during this final audit.

# Reproduce the TVT numerical records

Run from this directory. The frozen baseline used Python 3 with NumPy, SciPy, pandas and Matplotlib, MATLAB R2022b, and TeX Live 2026 with IEEEtran. Files under `data/` are included; these commands regenerate them if the same environments are available. The default v3 scripts and their CSVs remain unchanged in numerical meaning. No CarSim run is used.

1. Frozen estimator and cross-model records: `python scripts/cross_model_audit.py`; `python scripts/admissible_preview_experiment.py`; `python scripts/consistency_inputs.py`; then `matlab -batch "addpath('matlab'); run_estimator_consistency"`. The paired Python/MATLAB outputs are `data/estimator_common_inputs.csv`, `data/python_estimator_outputs.csv`, and `data/matlab_estimator_outputs.csv`.
2. Original 21 nonlinear MATLAB cases: `matlab -batch "addpath('matlab'); run_integrated_dynamics"`, yielding `data/integrated_dynamic_results.csv`. The evaluator truth is used for observation generation/evaluation, not fed to the estimator/controller.
3. Focused 30-seed estimator sensitivity: `python -c "import sys; sys.path.insert(0,'scripts'); from admissible_preview_experiment import run; run(Ns=(20,),visibilities=(15.,),seeds=range(30),epsilons=(.2,),output_prefix='tvt_primary30')"`. Outputs: `data/tvt_primary30_preview_results.csv` and `data/tvt_primary30_all_interval_products.csv`. Seeds 0–3 exactly reproduce the original last-follower four-seed means; seeds 4–29 retain the four declared curvature/outage profiles by seed modulo four while changing random draws.
4. Focused 10-seed D3/D4 MATLAB replay: `matlab -batch "addpath('matlab'); run_integrated_tvt_seeds"`. Seeds 5401–5410 are paired across methods and produce 60 rows in `data/tvt_D3_D4_paired_results.csv`. This script does not overwrite the original 21-case CSV or D3 traces.
5. Regenerate TVT Fig. 5 with `python scripts/plot_tvt.py`. Frozen figures 3, 4, 6 and 7 and the original tables remain CSV-derived through `python scripts/plot_v3.py` and `python scripts/build_supplement_tables.py`. The all-16 pair table is `tables/all_pairs_tvt.tex`, generated from `data/cross_model_transport_audit.csv` at p=1.
6. Compile PDFs: `latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex`.
7. Verify: `python scripts/verify_v3.py` and `python scripts/verify_tvt.py`. The former recomputes cross-model and 13,440 partial-preview interval products, checks 21 estimator comparisons, and checks 21 MATLAB dynamics records. The latter checks TVT-only 30-seed and 60-case claims, labels/citations, output files, and PDF page limit.

Run `python scripts/summarize_tvt_seeds.py` after the focused runs to regenerate `data/tvt_seed_summary.csv`, including means, interquartile ranges, and t intervals for all stated primary metrics and paired differences. `data/tvt_reference_metadata.json` preserves publisher-deposited Crossref metadata; `data/tvt_frozen_source_inventory.json` preserves hashes, CSV dimensions and Python syntax checks for the frozen source files.

The 30-seed t intervals and ten-seed paired differences are descriptive under fixed synthetic generator/scenario contracts. They are not independent measured-road or vehicle-population intervals. No multi-vehicle CarSim simulation, single-vehicle CarSim cross-validation, or high-fidelity vehicle evidence is claimed.
