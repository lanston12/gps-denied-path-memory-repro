# Appendix content audit

## Appendix A

Exact M1-M4 basis rows; M3 midpoint hinge and unsupported-direction explanation; M1/M2 and hinge primitives; polynomial coefficient recipe; cubic Bernstein coefficient matrix and evaluated heading/lateral rows; window retention; 121-node physical Gram weights and positive-definite subspace rule.

The main text supplies normalized station, general integral operators and the continuous physical-field metric. Appendix A evaluates and discretizes those objects, referring to their main equations rather than repeating those equations. Generic coefficient integration and the explicit Bernstein evaluations are an implementation recipe and its checkable special case.

## Appendix B

Nuisance-projected collocation normal equations; compatible independent basis changes for T/B/Q/J/P; whitened induced gain; physical meaning of support connector; four-hop extension; unrolled recurrence and injection/geometric-sum derivation; exact offline transport screen and distinct adaptive-bank gate.

The main theorem retains recursion, G, preceding-output factor, finite/uniform bounds, a three-hop example and full physical residual decomposition. Appendix B explains their algebra without repeating the theorem or complete bound. Full ten-hop and 16-pair tables remain outside the PDF.

## Appendix C

Omitted. Scenario formulas, vehicle/geometry assumptions and paired-seed setup fit in IV and Table II. Secondary dynamic peaks/timings, covariance increments, per-seed tables and commands are package material.
