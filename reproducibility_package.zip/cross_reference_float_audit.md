# Final integrated cross-reference and float audit

All 11 pages of the final PDF were rendered and visually inspected. Source/font-size settings are standard IEEEtran; original figure widths and caption/equation sizes were retained. Ragged-bottom typesetting prevents artificial expansion of paragraph/heading spacing.

| Object | First textual mention | Rendered page |
|---|---:|---:|
| Fig. 1. | 1 | 2 |
| Fig. 2. | 1 | 3 |
| Fig. 3. | 4 | 5 |
| Fig. 4. | 6 | 7 |
| Fig. 5. | 6 | 7 |
| Fig. 6. | 6 | 8 |
| Fig. 7. | 6 | 8 |
| TABLE I | 1 | 3 |
| TABLE II | 5 | 7 |

Fig. 6 and Fig. 7 share page 8, followed by the paired-result interpretation and consolidated limitations. Conclusion follows all seven principal figures and both tables. The former nearly empty Results page and redundant Table III are absent. The confirmed Acknowledgment and complete Data/Code Availability paragraph appear on page 9; Appendices A/B begin on page 9 and finish before References on page 10. The natural bibliography tail contains references 19-22 on page 11, balanced into two columns using IEEEtran's break at reference 21. Its remaining whitespace is final-page termination, not an isolated Results float or inserted blank page.

All labels/citations resolve. No duplicate labels, overfull boxes, clipped figures or broken glyphs were found. Every PDF font is embedded and no CJK/international-language font occurs. The framework's schematic input/output metric labels are explicitly mapped to the manuscript's hop indices in its caption. Main table text is normal body size.

`data/integrated_final_checks.json` records the current PDF/source hashes, figure/table positions, first mentions, page geometry and exact printed-primitive verification. `data/final_technical_checks.json` records the normalized-basis, interval-metric, publisher-metadata and source-preservation checks. The two inherited numeric verifiers also pass. Historical JSON retained with the source data is not the current final-layout record.

2026-09-29 update: reference 19 now explicitly lists its four authors. The PDF remains 11 pages, with unchanged reference numbering and pages 1–10 text. Reference pages 10–11 and framework page 2 were rendered/reviewed after compilation. The current PDF/source hashes are in `data/reference_recheck_metadata_20260929.json`; the two consolidation-stage JSON records named above retain their earlier hashes and validation history. External frozen-source checks could not be rerun because that directory is now absent.
