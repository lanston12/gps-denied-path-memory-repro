# Defensive-language audit

Claim honesty is retained while repeated exclusions are consolidated.

| Phrase family | Frozen main count | Integrated main count |
|---|---:|---:|
| `does not establish` | 3 | 0 |
| `do not establish` | 0 | 0 |
| `not field-calibrated` | 2 | 0 |
| `not measured hardware` | 1 | 0 |
| `not a calibrated` | 0 | 0 |
| `not contributions` | 1 | 0 |
| `not a proof` | 1 | 0 |
| `not field-sensor` | 1 | 0 |
| `not field coverage` | 0 | 0 |
| `not hardware` | 0 | 0 |

## Final locations

- Abstract: one positive sentence scopes the bounds/preview to accepted finite-basis models and declared scenarios; 184 whitespace-delimited words.
- III: local rank, metric, small-tangent-angle and valid-support assumptions remain at their equations. The pointwise quality index has one calibrated-band boundary and k_q has its engineering meaning.
- IV-C: one synthetic sensor/noise contract and measured-calibration statement. Pairing and fixed-scenario descriptions are experimental definitions, not repeated exclusions.
- V-D: one consolidated limitation paragraph distinguishes represented/full-field error, offline/online gate use, vehicle-state string stability/collision scope, and external calibration.
- VI: positive contributions/results/future work; no repeated safety/string-stability list.

The related-work table's `Not central` descriptions remain factual scope comparisons. Valid support, D5 unequal duration, resets, the distinct adaptive-bank gate and the conditional 30-m error are retained because they define the evidence's denominator or actual algorithm. They were not deleted as defensive wording.
