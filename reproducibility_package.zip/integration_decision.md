# Integration decision

**NO SEPARATE SUPPLEMENT.**

One self-contained main PDF contains the necessary framework, theorem, prefix rule, experiment assumptions, headline evidence and Appendices A/B. The complete source supplement is frozen in the previous directory; its raw tables and records are preserved externally, with every scientific unit classified in the integration audit.

The final natural layout is 11 pages, within the requested approximate 11-13 range and below TVT's 14-page initial regular-paper cap. An intermediate 10-page draft grew naturally after the remaining fusion-interface, zero-prefix and used-versus-model-horizon details were made explicit. The obsolete break at reference 12 was replaced with a final-tail balancing break at reference 21. No body/caption/equation/figure sizes were reduced and no content was added solely to fill pages.

The dynamic core is already conveyed by Fig. 7 and its D3/D4 discussion, so an additional dynamic-results table would repeat it. Table II instead combines essential experiment settings and D1-D5 scenarios. Table III and the five former supplementary raw tables stay out of the main PDF. Appendix C is not needed.
