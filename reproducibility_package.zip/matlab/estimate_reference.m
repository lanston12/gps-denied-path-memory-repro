function out=estimate_reference(localPts,remotePts,age,mode,epsilon)
% Same linearized curvature-basis estimator as scripts/reference_estimator.py.
% Source memory arrives as physical points in the receiver frame. Thus fitting
% it into the selected receiver basis is the cross-model projection.
W=30; sigma=.01; infoGate=1; residualGate=.03; p=1;
names={'M1','M2','M3','M4'};
all=cell(1,4); chosen=[];
for j=1:4
    all{j}=fit_one(localPts,W,names{j},sigma);
    if isempty(chosen) && all{j}.mu>=infoGate && ...
            all{j}.maxResidual<=residualGate
        chosen=all{j};
    end
end
if isempty(chosen)
    % Causal local fallback; report model gate failure and do not extend it.
    chosen=all{1}; modelValid=false;
else
    modelValid=true;
end
haveRemote=~isempty(remotePts) && age<=.8 && ~strcmp(mode,'local_only');
nominal=min(W,max(localPts(:,1)));
projRms=0; sourceModel='none';
if haveRemote
    nominal=min(W,max(nominal,max(remotePts(:,1))));
    sourceModel='sampled_physical_path';
    dst=fit_one(remotePts,W,chosen.model,sigma);
    projRms=dst.rmsResidual;
    if strcmp(mode,'v2v_only')
        chosen=dst;
    else
        Q=physical_q(W,chosen.model,max(localPts(:,1)));
        A=(eye(numel(chosen.coeff))+p*(Q\chosen.J))\eye(numel(chosen.coeff));
        chosen.coeff=A*dst.coeff+(eye(numel(chosen.coeff))-A)*chosen.coeff;
        % Translation and tangent anchor come from independent local points.
        chosen.support=nominal;
    end
end
chosen.support=nominal;
if ~haveRemote,age=0;end
qualityPreview=0;
if modelValid
    for s=0:.5:nominal
        if quality(chosen,s,projRms,age)<=epsilon
            qualityPreview=s;
        else
            break
        end
    end
end
if strcmp(mode,'admissible_fusion')
    usable=qualityPreview;
else
    usable=nominal;
end
if ~haveRemote
    usable=min(usable,max(localPts(:,1)));
end
if ~modelValid && strcmp(mode,'admissible_fusion'),usable=0;end
out=chosen;
out.modelValid=modelValid;out.ageValid=haveRemote;
out.nominal=nominal;out.admissible=usable;
out.qualityPreview=qualityPreview;
out.projectionRms=projRms;out.sourceModel=sourceModel;
out.remoteShortened=haveRemote && qualityPreview+1e-9<nominal;
end

function f=fit_one(points,W,model,sigma)
x=points(:,1);y=points(:,2);
[H,~,~]=basis_fields(x,W,model);
G=[ones(size(x)),x];D=[G,H];q=lsqminnorm(D,y);
res=y-D*q;
Hs=H-G*(G\H);J=(Hs'*Hs)/sigma^2;
Q=physical_q(W,model,max(x));
ev=eig(Q);
if min(ev)<=1e-12*max(ev)
    mu=0;
else
    C=chol(Q);Ci=C\eye(size(C));
    mu=max(0,min(eig(Ci'*J*Ci)));
end
f=struct('model',model,'W',W,'offset',q(1),'heading',q(2), ...
    'coeff',q(3:end),'J',J,'mu',mu,'support',max(x), ...
    'maxResidual',max(abs(res)),'rmsResidual',sqrt(mean(res.^2)));
end

function [H,P,K]=basis_fields(s,W,model)
s=s(:);u=s/W;
switch model
    case 'M1'
        K=ones(size(s));P=s;H=s.^2/2;
    case 'M2'
        K=[ones(size(s)),u];P=[s,s.^2/(2*W)];
        H=[s.^2/2,s.^3/(6*W)];
    case 'M3'
        z=max(s-W/2,0);
        K=[ones(size(s)),u,max(u-.5,0)];
        P=[s,s.^2/(2*W),z.^2/(2*W)];
        H=[s.^2/2,s.^3/(6*W),z.^3/(6*W)];
    case 'M4'
        poly=[1,-3,3,-1;0,3,-6,3;0,0,3,-3;0,0,0,1];
        H=zeros(numel(s),4);P=H;K=H;
        for j=1:4
            for n=0:3
                K(:,j)=K(:,j)+poly(j,n+1)*u.^n;
                P(:,j)=P(:,j)+poly(j,n+1)*s.^(n+1)/((n+1)*W^n);
                H(:,j)=H(:,j)+poly(j,n+1)*s.^(n+2)/((n+1)*(n+2)*W^n);
            end
        end
end
end

function Q=physical_q(W,model,support)
s=linspace(0,support,121)';
[H,P,K]=basis_fields(s,W,model);
Q=zeros(size(H,2));
for j=1:numel(s)
    Z=[H(j,:)/.2;P(j,:)/.02;K(j,:)/.002];
    wt=1;if j==1 || j==numel(s),wt=.5;end
    Q=Q+wt*(Z'*Z);
end
Q=Q/(numel(s)-1);
end

function r=quality(f,s,projRms,age)
[H,~,~]=basis_fields(s,f.W,f.model);
if rcond(f.J)<1e-12
    r=inf;return
end
v=max(0,H*(f.J\H'));
r=1.96*sqrt(v)+2*f.maxResidual+projRms+.02*age;
end
