function y=evaluate_reference(ref,s)
% Evaluate the accepted canonical finite-basis normal graph.
if isfield(ref,'localFallback') && ref.localFallback
    y=interp1(ref.rawPts(:,1),ref.rawPts(:,2),s,'linear','extrap');
    return
end
shape=size(s);s=s(:);W=ref.W;
switch ref.model
    case 'M1'
        H=s.^2/2;
    case 'M2'
        H=[s.^2/2,s.^3/(6*W)];
    case 'M3'
        z=max(s-W/2,0);
        H=[s.^2/2,s.^3/(6*W),z.^3/(6*W)];
    case 'M4'
        u=s/W;
        poly=[1,-3,3,-1;0,3,-6,3;0,0,3,-3;0,0,0,1];
        H=zeros(numel(s),4);
        for j=1:4
            for n=0:3
                H(:,j)=H(:,j)+poly(j,n+1)*s.^(n+2)/((n+1)*(n+2)*W^n);
            end
        end
end
y=reshape(ref.offset+ref.heading*s+H*ref.coeff,shape);
end
