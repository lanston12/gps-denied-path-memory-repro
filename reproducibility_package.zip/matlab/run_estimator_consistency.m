function run_estimator_consistency()
root=fileparts(fileparts(mfilename('fullpath')));
T=readtable(fullfile(root,'data','estimator_common_inputs.csv'));
rows=cell(max(T.case_id),1);
for cid=1:max(T.case_id)
    g=T(T.case_id==cid,:);
    local=g(strcmp(g.kind,'local'),:);
    remote=g(strcmp(g.kind,'remote'),:);
    o=estimate_reference([local.x_m,local.y_m],[remote.x_m,remote.y_m], ...
        g.age_s(1),'admissible_fusion',g.epsilon_ref_m(1));
    c=nan(1,4);c(1:numel(o.coeff))=o.coeff;
    rows{cid}=struct('case_id',cid,'model',string(o.model),'mu',o.mu, ...
        'model_valid',double(o.modelValid),'age_valid',double(o.ageValid), ...
        'nominal_m',o.nominal,'admissible_m',o.admissible, ...
        'projection_rms_m',o.projectionRms,'offset_m',o.offset, ...
        'heading',o.heading,'c1',c(1),'c2',c(2),'c3',c(3),'c4',c(4));
end
writetable(struct2table([rows{:}]),fullfile(root,'data','matlab_estimator_outputs.csv'));
end
