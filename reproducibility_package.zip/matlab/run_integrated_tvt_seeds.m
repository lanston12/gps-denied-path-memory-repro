function run_integrated_tvt_seeds()
% Paired nonlinear multi-vehicle study with the common M1--M4 estimator.
outdir = fullfile(fileparts(fileparts(mfilename('fullpath'))),'data');
seeds=0:9;
cases = {
    'D3_v2v_burst',10,'local_only';
    'D3_v2v_burst',10,'nominal_fusion';
    'D3_v2v_burst',10,'admissible_fusion';
    'D4_heterogeneous',20,'local_only';
    'D4_heterogeneous',20,'nominal_fusion';
    'D4_heterogeneous',20,'admissible_fusion'};
rows = cell(numel(seeds)*size(cases,1),1);
k=0;
for seed=seeds
 for c=1:size(cases,1)
    k=k+1;
    rows{k}=one_case(cases{c,1},cases{c,2},cases{c,3},seed);
    rows{k}.seed=seed;
    fprintf('%d/%d seed=%d %s %s margin=%.3f\n',k,numel(rows),seed, ...
        cases{c,1},cases{c,3},rows{k}.min_body_margin_m);
 end
end
T=struct2table([rows{:}]);
writetable(T,fullfile(outdir,'tvt_D3_D4_paired_results.csv'));
end

function result=one_case(scenario,N,method,seed)
rng(5401+seed);  % fixed prespecified seed, paired across methods.
timer=tic;
dt=.05; Tstop=16; steps=round(Tstop/dt);
gap=15; LdGoal=25; localVisible=15;
if strcmp(scenario,'D5_low_friction')
    mu=.35; vnom=18;
else
    mu=.85; vnom=18;
end
% State rows: X,Y,psi,vy,r,delta,vx.
state=zeros(N,7);
for i=1:N
    state(i,1)=-i*gap;
    state(i,2)=road_y(state(i,1),scenario);
    state(i,3)=atan(road_slope(state(i,1),scenario));
    state(i,7)=vnom;
end
mass=1450+45*(1:N)'; Iz=2400+100*(1:N)';
lf=1.15+.012*(1:N)'; lr=1.35+.009*(1:N)';
Cf=65000+500*(1:N)'; Cr=72000+450*(1:N)';
Tdelta=.14+.002*(1:N)';
lastRxPoints=cell(N,1);lastRxPose=cell(N,1);
lastAge=inf(N,1);
sensorNoise=.01*randn(steps,N+1,13,2);
linkNoise=.01*randn(steps,N,13,2);
minMargin=inf;maxEy=0;maxBeta=0;maxYaw=0;maxAy=0;
satCount=0;corridorCount=0;slipCount=0;previewSum=0;speedSum=0;
nominalSum=0;informationSum=0;remoteShortCount=0;modelValidCount=0;
fallbackCount=0;
ageValidCount=0;sumEy2=0;unavailableCount=0;
timeRecords=zeros(steps,5);
invalid=false;invalidReason="";executedSteps=steps;
for step=1:steps
    t=(step-1)*dt;
    visible=localVisible;
    if strcmp(scenario,'D1_curve_occlusion') && t>=7 && t<13
        visible=8;
    end
    comm=true;
    if strcmp(scenario,'D3_v2v_burst') && t>=5 && t<8.2
        comm=false;
    end
    % Virtual leader: road-following source with only locally seen points.
    leaderX=vnom*t;
    leaderY=road_y(leaderX,scenario);
    leaderPsi=atan(road_slope(leaderX,scenario));
    predPose=[leaderX,leaderY,leaderPsi];
    leaderPts=sensor_points(predPose,30,scenario,squeeze(sensorNoise(step,1,:,:)));
    leaderRef=estimate_reference(leaderPts,[],0,'local_only',.2);
    predMem=sample_reference(leaderRef,30);
    pathModel=cell(N,1);valid=zeros(N,1);
    for i=1:N
        pose=state(i,1:3);
        localPts=sensor_points(pose,visible,scenario,squeeze(sensorNoise(step,i+1,:,:)));
        haveRemote=false;
        if ~strcmp(method,'local_only') && comm && ~isempty(predMem)
            relPts=transform_points(predMem,predPose,pose);
            relPts=relPts+squeeze(linkNoise(step,i,:,:));
            haveRemote=true;
            lastAge(i)=0;
            lastRxPoints{i}=relPts;lastRxPose{i}=pose;
        elseif ~strcmp(method,'local_only') && lastAge(i)+dt<=.8 && ...
                ~isempty(lastRxPoints{i}) && strcmp(scenario,'D3_v2v_burst')
            % Locally propagated last accepted polynomial; finite age only.
            relPts=transform_points(lastRxPoints{i},lastRxPose{i},pose);
            haveRemote=true;
            lastAge(i)=lastAge(i)+dt;
        else
            lastAge(i)=lastAge(i)+dt;
        end
        if ~haveRemote,relPts=[];end
        ref=estimate_reference(localPts,relPts,lastAge(i),method,.2);
        ref.localFallback=false;
        valid(i)=max(0,ref.admissible);
        if strcmp(method,'admissible_fusion') && valid(i)<max(localPts(:,1))
            % Direct interpolation of measured local road points. This
            % fallback is labelled separately from model-admissible preview.
            ref.rawPts=localPts;ref.localFallback=true;
            valid(i)=max(localPts(:,1));
        end
        pathModel{i}=ref;
        nominalSum=nominalSum+ref.nominal;
        informationSum=informationSum+ref.qualityPreview;
        remoteShortCount=remoteShortCount+ref.remoteShortened;
        modelValidCount=modelValidCount+ref.modelValid;
        ageValidCount=ageValidCount+ref.ageValid;
        fallbackCount=fallbackCount+ref.localFallback;
        if valid(i)>0
            predMem=sample_reference(ref,valid(i));
        else
            predMem=[];
        end
        predPose=pose;
    end
    commonTarget=vnom;
    for i=1:N
        L=lf(i)+lr(i);
        if valid(i)>=2
            look=min(LdGoal,valid(i));
            ytarget=evaluate_reference(pathModel{i},look);
            deltaCmd=atan2(2*L*ytarget,look^2)-.12*state(i,5);
        else
            deltaCmd=0;
        end
        if abs(deltaCmd)>.45, satCount=satCount+1;end
        deltaCmd=max(-.45,min(.45,deltaCmd));
        dRate=max(-.5,min(.5,(deltaCmd-state(i,6))/Tdelta(i)));
        vx=max(3,state(i,7));vy=state(i,4);r=state(i,5);
        af=state(i,6)-atan2(vy+lf(i)*r,vx);
        ar=-atan2(vy-lr(i)*r,vx);
        Fzf=mass(i)*9.81*lr(i)/L; Fzr=mass(i)*9.81*lf(i)/L;
        Fyf=mu*Fzf*tanh(Cf(i)*af/(mu*Fzf));
        Fyr=mu*Fzr*tanh(Cr(i)*ar/(mu*Fzr));
        vyDot=(Fyf+Fyr)/mass(i)-vx*r;
        rDot=(lf(i)*Fyf-lr(i)*Fyr)/Iz(i);
        psi=state(i,3);
        state(i,1)=state(i,1)+dt*(vx*cos(psi)-vy*sin(psi));
        state(i,2)=state(i,2)+dt*(vx*sin(psi)+vy*cos(psi));
        state(i,3)=state(i,3)+dt*r;
        state(i,4)=state(i,4)+dt*vyDot;
        state(i,5)=state(i,5)+dt*rDot;
        state(i,6)=max(-.45,min(.45,state(i,6)+dt*dRate));
        state(i,7)=max(3,state(i,7)+dt*max(-2,min(2,(commonTarget-vx))));
        roadPsi=atan(road_slope(state(i,1),scenario));
        eY=(state(i,2)-road_y(state(i,1),scenario))*cos(roadPsi);
        ePsi=atan2(sin(state(i,3)-roadPsi),cos(state(i,3)-roadPsi));
        margin=1.8-(abs(eY)+.9+2.2*abs(sin(ePsi)));
        minMargin=min(minMargin,margin);
        maxEy=max(maxEy,abs(eY));maxBeta=max(maxBeta,abs(atan2(state(i,4),state(i,7))));
        maxYaw=max(maxYaw,abs(state(i,5)));
        maxAy=max(maxAy,abs(vyDot+vx*r));
        sumEy2=sumEy2+eY^2;
        corridorCount=corridorCount+(margin<0);
        slipCount=slipCount+(abs(atan2(state(i,4),state(i,7)))>.08);
        previewSum=previewSum+valid(i);speedSum=speedSum+state(i,7);
        unavailableCount=unavailableCount+(valid(i)<LdGoal);
    end
    timeRecords(step,:)=[t,min(valid),mean(valid),minMargin,mean(state(:,7))];
    if maxBeta>.3 || maxEy>5
        invalid=true;invalidReason="large sideslip or lateral departure";
        executedSteps=step;
        break
    end
end
result=struct('scenario',scenario,'N',N,'method',method, ...
    'min_body_margin_m',minMargin,'max_lateral_error_m',maxEy, ...
    'lateral_rmse_m',sqrt(sumEy2/(executedSteps*N)), ...
    'max_sideslip_rad',maxBeta,'max_yaw_rate_radps',maxYaw, ...
    'max_lateral_accel_mps2',maxAy, ...
    'corridor_violation_fraction',corridorCount/(executedSteps*N), ...
    'sideslip_violation_fraction',slipCount/(executedSteps*N), ...
    'steering_saturation_fraction',satCount/(executedSteps*N), ...
    'mean_valid_preview_m',previewSum/(executedSteps*N), ...
    'mean_nominal_preview_m',nominalSum/(executedSteps*N), ...
    'mean_information_admissible_preview_m',informationSum/(executedSteps*N), ...
    'remote_rejected_or_shortened_fraction',remoteShortCount/(executedSteps*N), ...
    'model_valid_fraction',modelValidCount/(executedSteps*N), ...
    'age_valid_fraction',ageValidCount/(executedSteps*N), ...
    'raw_local_fallback_fraction',fallbackCount/(executedSteps*N), ...
    'preview_below_goal_fraction',unavailableCount/(executedSteps*N), ...
    'mean_speed_mps',speedSum/(executedSteps*N), ...
    'computation_s',toc(timer), ...
    'validity_terminated',invalid,'termination_time_s',executedSteps*dt, ...
    'termination_reason',invalidReason);
end

function pts=sensor_points(pose,visible,scenario,noise)
s=linspace(0,visible,13)';
world=[pose(1)+s,road_y(pose(1)+s,scenario)];
c=cos(pose(3));q=sin(pose(3));
R=[c q;-q c];
pts=(world-pose(1:2))*R';
pts=pts+noise;
end

function points=sample_reference(ref,horizon)
x=linspace(0,horizon,13)';
points=[x,evaluate_reference(ref,x)];
end

function points=transform_points(predPts,predPose,receiverPose)
cp=cos(predPose(3));sp=sin(predPose(3));
Rp=[cp -sp;sp cp];
world=predPts*Rp'+predPose(1:2);
cr=cos(receiverPose(3));sr=sin(receiverPose(3));
Rr=[cr sr;-sr cr];
points=(world-receiverPose(1:2))*Rr';
end

function y=road_y(x,scenario)
switch scenario
    case 'D1_curve_occlusion'
        y=2*sin(x/50)+.4*sin(x/12);
    case 'D2_s_curve'
        y=1.75*tanh((x-20)/12)-1.75*tanh((x-95)/12);
    case 'D3_v2v_burst'
        y=2*sin(x/40);
    case 'D4_heterogeneous'
        y=3*sin(x/35)+.6*sin(x/15);
    case 'D5_low_friction'
        y=5*sin(x/18);
end
end

function slope=road_slope(x,scenario)
dx=.01;
slope=(road_y(x+dx,scenario)-road_y(x-dx,scenario))/(2*dx);
end
