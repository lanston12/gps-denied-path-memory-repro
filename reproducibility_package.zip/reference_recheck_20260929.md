# 参考文献复核（2026-09-29）

## 结论

已逐条核对论文现有 22 条参考文献：20 条通过 DOI 获取出版方最新 Crossref 记录，另外 2 条核对 arXiv 官方记录。作者及顺序、题名、期刊、正式刊期年份、卷期、页码／文章号、DOI（适用时）均未发现实质错误。

## 第 19 条

- 作者：Ahmed Khalifa、Olivier Kermorgant、Salvador Dominguez、Philippe Martinet。
- 题名：Platooning of Car-Like Vehicles in Urban Environments: Longitudinal Control Considering Actuator Dynamics, Time Delays, and Limited Communication Capabilities。
- 期刊：IEEE Transactions on Control Systems Technology，29(6)，2670–2677，2021 年 11 月。
- DOI：[10.1109/TCST.2020.3044786](https://doi.org/10.1109/TCST.2020.3044786)。

IEEE 控制系统学会的[2021 年 11 月期刊目录](https://ieeecss.org/sites/ieeecss/files/documents/pcd/CSS_Publications_Content_Digest_112021.pdf)和[合作者的机构个人主页](https://pagesperso.ls2n.fr/~kermorgant-o/publications.html)提供独立佐证。机构主页标注 2020 年在线发表；正式刊期为 2021 年，文献中的年份正确。

第 18 条为同一作者组在 IEEE Transactions on Intelligent Transportation Systems 发表的 observer-based 论文，DOI 为 10.1109/TITS.2020.2988948，22(9)，5684–5696，2021。第 19 条为 TCST 的纵向控制论文，两条题名、期刊和 DOI 不同，分别保留。正文将它们用于通信与车辆行为的相关工作，引用用途与文献主题相符。

原 PDF 中第 19 条的横线是 IEEEtran 对连续相同作者的自动替代。本次通过其正式 CTLdash_repeated_names 控制项关闭该替代，明确列出四位作者。独立 bibliography_control.bib 存放格式设置，不产生参考文献编号。references.bib 的 22 条科学文献保持原样，编号和正文引用不变。

## 其他核对事项

第 11 条的 Crossref 作者字段包含 Xian-Xu Bai 的昵称 Frank，且引号编码损坏。文献沿用规范姓名 Xian-Xu Bai，身份及作者顺序一致。第 6 条以正式刊期 2025 年记载，并保留 2024 年在线发表说明；第 9 条的 ACC 会议页码与 arXiv 的 journal-reference 一致；第 20 条明确标为预印本。

## 重新编译与复核

- latexmk/BibTeX 编译成功；22 个唯一编号，第 19 条四位作者均明确显示。
- PDF 仍为 11 页；第 10–11 页参考文献排版已经渲染并目视检查，第 2 页亦复查。
- 第 1–10 页提取文本与修改前完全一致；第 11 页仅作者展示发生变化。
- 全部字体嵌入，无未解析引用、重复标签或 overfull；文本均在页面边界内。
- 原始 references.bib 与修改前副本及已有冻结清单哈希一致；77 项继承代码／CSV 哈希一致。
- verify_v3.py 与 verify_tvt.py 本次通过。

溯源限制：先前冻结目录 GPS_denied_path_memory_TVT_final_audit 已不在主文件夹中，因此依赖它的 verify_final_audit.py 和 verify_integrated.py 本次无法完成原目录 202 文件复查。保留其原验证脚本及之前记录，未删除检查条件。本次参考文献的最新在线元数据与排版检查已独立完成。当前 fig1.png 在本次任务前已于 2026-09-28 更新，相对旧清单哈希有差异；本次未编辑该图。

当前复核结果及 PDF/TeX 哈希见 data/reference_recheck_metadata_20260929.json；先前整合检查 JSON 保留为历史记录。

## All 22 records

| No. | Reference key | Source | Result |
|---:|---|---|---|
| 1 | `lee2020path` | [Metadata](https://api.crossref.org/works/10.3390/s20247022) | Verified |
| 2 | `liu2021preview` | [Metadata](https://api.crossref.org/works/10.1109/TIV.2020.3033773) | Verified |
| 3 | `wang2026historical` | [Metadata](https://api.crossref.org/works/10.1016/j.conengprac.2025.106721) | Verified |
| 4 | `hassanain2020steering` | [Metadata](https://api.crossref.org/works/10.1080/00423114.2020.1749288) | Verified |
| 5 | `bayuwindra2020lookahead` | [Metadata](https://api.crossref.org/works/10.1109/TCST.2019.2893830) | Verified |
| 6 | `zuo2024pathcoupled` | [Metadata](https://api.crossref.org/works/10.1109/TIV.2024.3376797) | Verified |
| 7 | `feng2019survey` | [Metadata](https://api.crossref.org/works/10.1016/j.arcontrol.2019.03.001) | Verified |
| 8 | `ploeg2014string` | [Metadata](https://api.crossref.org/works/10.1109/TITS.2013.2291493) | Verified |
| 9 | `li2026lateral` | [Metadata](https://arxiv.org/abs/2606.29677) | Verified |
| 10 | `feng2024dmpc` | [Metadata](https://api.crossref.org/works/10.1109/TITS.2023.3323478) | Verified |
| 11 | `wang2023holistic` | [Metadata](https://api.crossref.org/works/10.1109/TVT.2023.3289632) | Verified |
| 12 | `fei2025trajectory` | [Metadata](https://api.crossref.org/works/10.1016/j.trc.2025.105049) | Verified |
| 13 | `zhao2021nonideal` | [Metadata](https://api.crossref.org/works/10.1109/TVT.2020.3046165) | Verified |
| 14 | `barooah2025lanechange` | [Metadata](https://api.crossref.org/works/10.1109/TVT.2025.3531990) | Verified |
| 15 | `lan2020delay` | [Metadata](https://api.crossref.org/works/10.1109/TVT.2020.3025729) | Verified |
| 16 | `li2019unreliable` | [Metadata](https://api.crossref.org/works/10.1109/TVT.2019.2891681) | Verified |
| 17 | `xu2022switching` | [Metadata](https://api.crossref.org/works/10.1109/TVT.2022.3153562) | Verified |
| 18 | `khalifa2021observer` | [Metadata](https://api.crossref.org/works/10.1109/TITS.2020.2988948) | Verified |
| 19 | `khalifa2021longitudinal` | [Metadata](https://api.crossref.org/works/10.1109/TCST.2020.3044786) | Verified |
| 20 | `li2026formulation` | [Metadata](https://arxiv.org/abs/2605.01731) | Verified |
| 21 | `somisetty2024lateral` | [Metadata](https://api.crossref.org/works/10.1109/ICVES61986.2024.10927795) | Verified |
| 22 | `liu2026robust` | [Metadata](https://api.crossref.org/works/10.1109/TITS.2026.3709255) | Verified |
