"""Final notation, stored-evidence and rendered-float audit; no new simulations."""
from pathlib import Path
import hashlib, html, json, re, subprocess, sys
import numpy as np
import pandas as pd
import fitz
from scipy.integrate import quad
from reference_estimator import fields

ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'main.tex').read_text(encoding='utf-8')
supp=(ROOT/'supplement.tex').read_text(encoding='utf-8')
assert r'\bar K_m(v/W)' in main and r'\bar K_m(v/W)' in supp
assert r'H_{m_i}(s)' not in main
assert r'\widetilde G_{j:i}=c_jG_{j:i}' in main+supp
assert r'k_q=1.96' in main and r'k_q=1.96' in supp
assert 'design shape-information matrix' in main and 'design shape-information matrix' in supp
assert r'\FloatBarrier' in main
assert 'CarSim' not in main+supp
abstract=main.split(r'\begin{abstract}')[1].split(r'\end{abstract}')[0]
assert 180<=len(abstract.split())<=210
assert '30 paired' in abstract and '23.02' in abstract and '21 recorded' not in abstract

# Compare exact primitives with independent quadrature of normalized bases.
def basis(u, model):
    return {'M1':[1.], 'M2':[1.,u], 'M3':[1.,u,max(u-.5,0.)],
            'M4':[(1-u)**3,3*u*(1-u)**2,3*u*u*(1-u),u**3]}[model]
err=0.
for W in (8.,15.,30.):
    for s in (W/4,W/2,W):
        for m in ('M1','M2','M3','M4'):
            H,P,K=fields([s],W,m)
            assert np.allclose(K[0],basis(s/W,m),rtol=1e-12,atol=1e-12)
            for q in range(K.shape[1]):
                points=[W/2] if s>W/2 else None
                p=quad(lambda v:basis(v/W,m)[q],0,s,points=points)[0]
                h=quad(lambda v:(s-v)*basis(v/W,m)[q],0,s,points=points)[0]
                err=max(err,abs(P[0,q]-p),abs(H[0,q]-h))
assert err<1e-10
mat=(ROOT/'matlab/estimate_reference.m').read_text(encoding='utf-8')
for token in ('u=s/W','s.^3/(6*W)','z.^3/(6*W)','((n+1)*(n+2)*W^n)'):
    assert token in mat,token

# Explicit 3-/4-hop check against every matching stored interval.
c=pd.read_csv(ROOT/'data/cross_model_transport_audit.csv')
iv=pd.read_csv(ROOT/'data/cross_model_interval_products.csv')
checked=0
for row in iv.itertuples():
    n=row.end_hop-row.start_hop+1
    if n not in (3,4):continue
    z=c[(c.sequence==row.sequence)&(c.p==row.p)&
        c.hop.between(row.start_hop,row.end_hop)].sort_values('hop')
    expected=z.physical_gain.prod()*z.connector_from_previous.iloc[1:].prod()
    assert np.isclose(expected,row.raw_product,atol=1e-14,rtol=1e-10)
    assert np.isclose(expected*z.connector_from_previous.iloc[0],z.chain_gain.prod(),atol=1e-14)
    checked+=1
h6=c[(c.sequence=='realized')&(c.p==1)&(c.hop==6)].iloc[0]
assert h6.physical_gain<1<h6.chain_gain
assert np.isclose(h6.chain_gain,1.5054498092303918)
bank=pd.read_csv(ROOT/'data/adaptive_model_bank.csv')
r=bank[(bank.start_m==35)&(bank.W_m==30)&(bank.model=='M2_affine')].iloc[0]
assert r.information_pass and not r.model_pass and np.isclose(r.max_abs_residual_m,.048561,atol=1e-6)

# Frozen source and every inherited CSV/simulation source remain byte-identical.
manifest=json.loads((ROOT/'data/frozen_tvt_manifest.json').read_text(encoding='utf-8'))
frozen=ROOT.parent/'GPS_denied_path_memory_TVT_submission'
for item in manifest:
    p=item['path']; expected=item['sha256']
    assert hashlib.sha256((frozen/p).read_bytes()).hexdigest()==expected,p
    if p.endswith(('.csv','.m')) or (p.startswith('scripts/') and p.endswith('.py')):
        assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==expected,p

# Parse fields with brace balancing, then compare publisher title/year/DOI.
bib=(ROOT/'references.bib').read_text(encoding='utf-8')
entries={}
for match in re.finditer(r'@\w+\{([^,]+),',bib):
    key=match.group(1);start=match.end();depth=1;pos=start
    while depth:
        if bib[pos]=='{':depth+=1
        elif bib[pos]=='}':depth-=1
        pos+=1
    body=bib[start:pos-1];entry={}
    for field in ('title','year','doi','volume','number','pages'):
        fm=re.search(r'\b'+field+r'\s*=\s*\{',body)
        if not fm:continue
        k=fm.end();end=k;level=1
        while level:
            if body[end]=='{':level+=1
            elif body[end]=='}':level-=1
            end+=1
        entry[field]=body[k:end-1]
    entries[key]=entry
assert len(entries)==22
def norm(s):return re.sub(r'[^a-z0-9]','',html.unescape(s).lower())
metadata=json.loads((ROOT/'data/final_reference_metadata.json').read_text(encoding='utf-8'))
for key,m in metadata.items():
    b=entries[key]
    assert norm(b['title'])==norm(m['title'][0]),(key,'title')
    assert b['doi'].lower()==m['DOI'].lower(),(key,'doi')
    assert int(b['year'])==m['published']['date-parts'][0][0],(key,'year')
    if 'volume' in b:assert b['volume']==m['volume'],(key,'volume')
    if 'number' in b:assert b['number']==m['issue'],(key,'issue')
    if 'pages' in b:assert norm(b['pages'])==norm(m['page']), (key,'pages')

# Rendered reading-order checks. Full-width floats are compared geometrically.
doc=fitz.open(ROOT/'main.pdf')
def find(text):
    return [(i+1,tuple(rect)) for i,p in enumerate(doc) for rect in p.search_for(text)]
discussion=find('VIII. DISCUSSION')[0]
conclusion=find('IX. CONCLUSION')[0]
references=next((i+1,tuple(line['bbox'])) for i,p in enumerate(doc)
               for block in p.get_text('dict')['blocks'] for line in block.get('lines',[])
               if ''.join(span['text'] for span in line['spans']).strip()=='REFERENCES')
assert discussion[0]<=conclusion[0]<=references[0]
float_positions={}
for token in ('Fig. 4.','Fig. 5.','Fig. 6.','Fig. 7.','TABLE III'):
    pos=find(token)[0];float_positions[token]=pos
    assert pos[0]<discussion[0] or (pos[0]==discussion[0] and pos[1][3]<discussion[1][1]),token
for num in range(1,8):
    cap=find(f'Fig. {num}.')[0]
    mentions=find(f'Fig. {num}')
    assert any(p<cap[0] or (p==cap[0] and (r[2]<cap[1][0] or r[3]<cap[1][1])) for p,r in mentions),num
pdfs={}
for name in ('main','supplement'):
    d=fitz.open(ROOT/(name+'.pdf'))
    assert len(d)<=14 if name=='main' else len(d)>0
    log=(ROOT/(name+'.log')).read_text(errors='replace')
    for bad in ('Overfull','undefined references','There were undefined','multiply defined'):
        assert bad not in log,(name,bad)
    f=subprocess.check_output(['pdffonts',str(ROOT/(name+'.pdf'))],text=True).splitlines()[2:]
    assert all(line.split()[-5]=='yes' for line in f if line.strip())
    assert not any(re.search(r'CJK|SimSun|SimHei|MS-Mincho|NotoSansCJK',line,re.I) for line in f)
    pdfs[name]={'pages':len(d),'all_fonts_embedded':True,'sha256':hashlib.sha256((ROOT/(name+'.pdf')).read_bytes()).hexdigest()}
result={'status':'pass','basis_max_integral_difference':err,'three_four_hop_intervals_checked':checked,
        'frozen_files_unchanged':len(manifest),'bibliography_entries':len(entries),
        'publisher_records_checked':len(metadata),'abstract_words':len(abstract.split()),
        'pdfs':pdfs,'result_float_positions':float_positions,'discussion_position':discussion}
(ROOT/'data/final_technical_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('PASS: normalized primitives, interval metric convention, frozen files, metadata, rendered float order, fonts, logs')
