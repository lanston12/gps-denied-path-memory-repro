# Integrated-final revision log

Source: latest frozen `GPS_denied_path_memory_TVT_final_audit` main and supplement only. Destination: new independent `GPS_denied_path_memory_TVT_integrated_final`. A 202-file source inventory checks that the entire earlier directory remains unchanged (excluding its temporary/cache files).

1. Read the complete main/supplement and classified every supplement paragraph/display/table; selected narrative, technical appendices and external records.
2. Consolidated nine numbered sections into six; merged reconstruction/propagation/preview into III, and Results/Discussion into V.
3. Retained theorem, explicit metric starts/connectors and three-hop example in main; placed basis expansions/discretization and compatible coordinate/interval algebra in A/B.
4. Added explicit follower/hop indexing and theta_i path-tangent angle, preserving psi_i body yaw.
5. Formalized the already implemented quality/prefix rules; consolidated repeated claim boundaries and retained all denominator/operational distinctions.
6. Combined experiment settings and D1-D5 formulas in Table II; removed redundant Table III and kept the five raw supplement tables external.
7. Retained primary 30-seed results, paired D3/D4 records, stored hop-6 connector example, all seven figure assets and 22 bibliography entries.
8. Kept author-confirmed AI acknowledgment verbatim. No broader/narrower usage claim or author information added.
9. Redistributed Fig. 7 before its seed interpretation; Fig. 6/7 now share the formerly sparse page 8. Replaced the obsolete reference-12 trigger with reference-21 balancing for the natural final bibliography tail. Standard fonts and original figure sizes are retained.
10. Migrated the three verifier file/section/float contracts to the single-PDF structure. Original verifiers are preserved byte-for-byte under `reproducibility/legacy_verification`; numerical checking bodies and scientific generators retain their original purpose.
11. No simulation or new data was generated. Final verification/layout outcome is recorded in the current audit JSON files and readiness document.

12. Made the existing matched-interface coefficient fusion, zero-horizon convention and used-versus-model-admissible preview distinction explicit. These are clarification of the stored implementation, not a new algorithm or experiment. The framework caption identifies the precise input/output hop indices.
13. Final main PDF: 11 pages; abstract 184 words; six main sections, two appendices, seven figures, two tables, 22 references; no separate supplement. All four current verifiers pass and all pages were rendered/reviewed. Source hashes confirm the earlier version was untouched. Created the external reproducibility archive from preserved code/data/assets and current audit instructions.

14. 2026-09-29 reference recheck: all 22 records verified against 20 fresh publisher Crossref records and two official arXiv records. No bibliographic correction required. Disabled IEEEtran's automatic repeated-author dash through `bibliography_control.bib`, so reference 19 explicitly lists all four authors; numbering and `references.bib` are unchanged. Recompiled to 11 pages and reviewed the reference pages. The current PDF hashes and recheck results are in `data/reference_recheck_metadata_20260929.json`. Two stored-data verifiers pass; the two original-source verifiers cannot complete because the earlier frozen directory is no longer present. Consolidation-stage audit results above are historical. See `reference_recheck_20260929.md`.
