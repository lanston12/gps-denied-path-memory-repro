"""Four modest curvature models with joint pose fitting and model-validity gate."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from scipy.integrate import cumulative_trapezoid
from path_model import rot

D=Path(__file__).resolve().parents[1]/"data"
GX,GW=np.polynomial.legendre.leggauss(28)
MODELS=("M1_constant","M2_affine","M3_piecewise_affine","M4_cubic_bspline")

def basis(u,model):
    u=np.asarray(u)
    if model==MODELS[0]: return np.stack([np.ones_like(u)],-1)
    if model==MODELS[1]: return np.stack([np.ones_like(u),u],-1)
    if model==MODELS[2]: return np.stack([np.ones_like(u),u,np.maximum(0,u-.5)],-1)
    return np.stack([(1-u)**3,3*u*(1-u)**2,3*u*u*(1-u),u**3],-1)

def primitive(u,model):
    u=np.asarray(u)
    if model==MODELS[0]: return np.stack([u],-1)
    if model==MODELS[1]: return np.stack([u,u*u/2],-1)
    if model==MODELS[2]:
        return np.stack([u,u*u/2,np.maximum(0,u-.5)**2/2],-1)
    return np.stack([(1-(1-u)**4)/4,
                     1.5*u*u-2*u**3+.75*u**4,
                     u**3-.75*u**4,u**4/4],-1)

def geometry(s,c,W,model):
    s=np.asarray(s,float).reshape(-1)
    t=s[:,None]*(GX[None,:]+1)/2
    wt=s[:,None]*GW[None,:]/2
    A=primitive(t/W,model)
    psi=W*np.einsum("nqc,c->nq",A,c)
    tangent=np.stack([np.cos(psi),np.sin(psi)],-1)
    normal=np.stack([-np.sin(psi),np.cos(psi)],-1)
    points=np.sum(wt[...,None]*tangent,axis=1)
    jac=np.einsum("nq,nqa,nqc->nac",wt,normal,W*A)
    return points,jac

def fit(s,obs,W,model,eps):
    n=len(s); d=len(basis(np.array([0.]),model)[0])
    theta=np.arctan2(*(obs[1]-obs[0])[::-1])
    q0=np.r_[obs[0],theta,np.full(d,.001)]
    def eval(q):
        p,jc=geometry(s,q[3:],W,model)
        R=rot(q[2])
        pred=p@R.T+q[:2]
        jp=np.zeros((n,2,3))
        jp[:,:,:2]=np.eye(2)[None,:,:]
        jp[:,:,2]=p@(R@np.array([[0,-1],[1,0]])).T
        J=np.concatenate([jp,np.einsum("ab,nbc->nac",R,jc)],2).reshape(-1,3+d)
        return (pred-obs).reshape(-1),J
    result=least_squares(lambda q:eval(q)[0],q0,jac=lambda q:eval(q)[1],
                         x_scale=np.r_[1.,1.,.1,np.full(d,.002)],
                         max_nfev=100)
    residual,J=eval(result.x)
    G,H=J[:,:3],J[:,3:]
    He=H-G@np.linalg.lstsq(G,H,rcond=None)[0]
    info=He.T@He/(eps/np.sqrt(3))**2
    mu=max(0.,float(np.linalg.eigvalsh(info)[0]))
    # Metric is integrated physical lateral, heading and curvature response.
    grid=np.linspace(0,W,101)
    _,jc=geometry(grid,result.x[3:],W,model)
    psi=W*np.einsum("nc,c->n",primitive(grid/W,model),result.x[3:])
    normal=np.stack([-np.sin(psi),np.cos(psi)],-1)
    jy=np.einsum("na,nac->nc",normal,jc)
    jpsi=W*primitive(grid/W,model)
    jk=basis(grid/W,model)
    Z=np.stack([jy/.2,jpsi/.02,jk/.002],1)
    Q=np.trapz(np.einsum("nac,nad->ncd",Z,Z),grid,axis=0)/W
    C=np.linalg.cholesky(Q).T
    Ci=np.linalg.inv(C)
    phys_info=np.linalg.eigvalsh(Ci.T@info@Ci)[0]
    return {"coeff":result.x[3:],"max_abs_residual_m":float(np.max(np.abs(residual))),
            "rms_residual_m":float(np.sqrt(np.mean(residual**2))),
            "mu_coeff":mu,"mu_phys":max(0.,float(phys_info)),
            "converged":bool(result.success)}

def composite_road():
    ss=np.linspace(0,80,8001)
    k=np.select([ss<10,ss<30,ss<50,ss<=80],
                [0,.012*(ss-10)/20,.012,
                 .012*np.cos(2*np.pi*(ss-50)/30)],default=0.)
    psi=cumulative_trapezoid(k,ss,initial=0)
    x=cumulative_trapezoid(np.cos(psi),ss,initial=0)
    y=cumulative_trapezoid(np.sin(psi),ss,initial=0)
    return ss,x,y,psi

def run():
    ss,x,y,psi=composite_road()
    rows=[]
    for start in [0,8,12,20,28,35,42,49,55,62,68]:
        for W in [8.,12.,15.,20.,30.]:
            if start+W>80: continue
            s=np.linspace(0,W,max(10,int(W/2)))
            global_s=start+s
            xy=np.stack([np.interp(global_s,ss,x),np.interp(global_s,ss,y)],1)
            origin=np.array([np.interp(start,ss,x),np.interp(start,ss,y)])
            local=(xy-origin)@rot(-np.interp(start,ss,psi)).T
            for order,model in enumerate(MODELS,1):
                f=fit(s,local,W,model,.01)
                rows.append({"start_m":start,"W_m":W,"model":model,"order":order,
                             **{k:v for k,v in f.items() if k!="coeff"}})
    out=pd.DataFrame(rows)
    out["model_pass"]=out.max_abs_residual_m<=.01
    out["information_pass"]=out.mu_phys>=4.
    out["accepted"]=out.model_pass & out.information_pass & out.converged
    out.to_csv(D/"adaptive_model_bank.csv",index=False)
    selected=(out[out.accepted].sort_values(["start_m","W_m","order"],
                                            ascending=[True,False,True])
              .drop_duplicates("start_m"))
    selected.to_csv(D/"adaptive_model_selection.csv",index=False)
    print("windows",out.start_m.nunique(),"selected",len(selected))
    print(selected[["start_m","W_m","model","max_abs_residual_m","mu_phys"]].to_string(index=False))
    print("fixed affine 30m passes",out[(out.model==MODELS[1])&(out.W_m==30)].accepted.sum())
    return out

if __name__=="__main__":
    run()
