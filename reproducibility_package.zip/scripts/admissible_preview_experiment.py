"""Station-matched synthetic path-information strings, with explicit support.

No vehicle dynamics are simulated here. The remote path is the previous
vehicle's estimated physical segment, registered by a noisy relative anchor.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from reference_estimator import (estimate_reference, fit_model, path_points, fields,
    cross_model, local_information, induced, physical_Q)

D=Path(__file__).resolve().parents[1]/'data'
VIS=(8.,12.,15.,30.)
EPS=(.1,.2,.5)
METHODS=('local_only','v2v_only','pose_v2v','fused')

def gain(previous, current, vis, use_local):
    if previous is None or current is None:return 0.
    a,b=previous['model'],current['model']
    T,Qa,Qb,_,_=cross_model(a,b,0.,30.,30.)
    if use_local and current.get('model_valid',False):
        J=local_information(np.linspace(0,vis,16),30.,b)
        Qlocal=physical_Q(30.,b,vis)
        A=np.linalg.solve(np.eye(Qb.shape[0])+np.linalg.solve(Qlocal,J),
                          np.eye(Qb.shape[0]))
        T=A@T
    return induced(T,Qb,Qa)

def run(Ns=(5,10,20), visibilities=VIS, seeds=range(4), epsilons=EPS,
        output_prefix='admissible'):
    rows=[];products=[]
    for N in Ns:
      for vis in visibilities:
       for seed in seeds:
        rng=np.random.default_rng(36510+seed+int(vis)*100)
        seed_group=seed%4
        true=np.array([.004+.00025*seed_group,.0015])
        observations=[]
        for i in range(1,N+1):
            s=np.linspace(0,vis,16)
            offset=rng.uniform(-.1,.1);heading=rng.uniform(-.01,.01)
            true_i=true+np.array([.00003*i,.00002*np.sin(i)])
            local=np.column_stack([s,path_points(s,30.,'M2',true_i,offset,heading)+
                                      rng.normal(0,.006,len(s))])
            anchor_noise=rng.normal(0,[.01,.001])
            remote_noise=rng.normal(0,.005,16)
            age=.9 if (seed_group==3 and i%7==0) else rng.uniform(0,.25)
            observations.append((true_i,local,offset,heading,anchor_noise,remote_noise,age))
        for epsilon in epsilons:
         for method in METHODS:
            lead_s=np.linspace(0,30,16)
            lead_pts=np.column_stack([lead_s,path_points(lead_s,30.,'M2',true)])
            previous=fit_model(lead_pts,30.,'M2')
            previous.update(admissible=30.,nominal=30.,model_valid=True,
                            cov_shape=np.diag([1e-8,1e-8]),
                            anchor_cov=np.diag([1e-4,1e-6]))
            gain_list=[]
            for i,(truth,local,offset,heading,anchor_noise,remote_noise,age) in enumerate(observations,1):
                valid_remote=(method!='local_only' and previous is not None and
                              previous['support']>=30. and
                              previous['model_valid'] and age<=.8)
                remote=None
                if valid_remote:
                    sr=np.linspace(0,30,16)
                    yr=path_points(sr,30.,previous['model'],previous['coeff'],
                                   offset+anchor_noise[0],heading+anchor_noise[1])
                    remote=np.column_stack([sr,yr+remote_noise])
                if method=='local_only':
                    out=estimate_reference(local,None,age,'local_only',epsilon)
                    out['admissible']=min(out['quality_preview'],vis)
                elif method=='fused':
                    out=estimate_reference(local,remote,age,'admissible_fusion',epsilon)
                elif valid_remote:
                    # No local shape update; pose_v2v only resets the anchor.
                    out=fit_model(remote,30.,'M2')
                    out['model_valid']=out['max_residual']<=.03
                    out['age_valid']=True
                    out['nominal']=30.;out['support']=30.
                    out['offset']=offset if method=='pose_v2v' else out['offset']
                    out['heading']=heading if method=='pose_v2v' else out['heading']
                    # No local shape reset: carry the predecessor coefficient
                    # covariance and one declared per-hop process covariance.
                    out['cov_shape']=previous['cov_shape']+np.diag([1e-8,1e-8])
                    out['anchor_cov']=(np.diag([.005**2,.0005**2])
                                       if method=='pose_v2v' else
                                       previous['anchor_cov']+np.diag([.01**2,.001**2]))
                    eligible=[]
                    for station in np.arange(0,30.5,.5):
                        h=fields([station],30.,'M2')[0][0]
                        a=np.array([1.,station])
                        variance=h@out['cov_shape']@h+a@out['anchor_cov']@a
                        radius=1.96*np.sqrt(variance)+2*out['max_residual']+.02*age
                        if radius<=epsilon:
                            eligible.append(station)
                        else:
                            break
                    out['admissible']=max(eligible,default=0.) if out['model_valid'] else 0.
                else:
                    out={'model':'M2','coeff':np.zeros(2),'offset':0.,'heading':0.,
                         'model_valid':False,'age_valid':False,'nominal':0.,
                         'admissible':0.,'support':0.}
                gamma=gain(previous,out,vis,method=='fused') if valid_remote else 0.
                gain_list.append(gamma)
                far_error=(abs(path_points([30],30.,out['model'],out['coeff'],
                                           out['offset'],out['heading'])[0]-
                               path_points([30],30.,'M2',truth,offset,heading)[0])
                           if out['support']>=30. else np.nan)
                rows.append(dict(N=N,visible_m=vis,seed=seed,epsilon_ref_m=epsilon,
                                 method=method,vehicle_index=i,
                                 nominal_preview_m=out['nominal'],
                                 admissible_preview_m=out['admissible'],
                                 far_30m_error_m=far_error,
                                 physical_gain=gamma,
                                 model_valid=int(out['model_valid']),
                                 age_valid=int(out['age_valid']),
                                 selected_model=out['model']))
                # Nominal support can be relayed while its admissibility is
                # separately screened; invalid model/age cannot be relayed.
                previous=out
            if method=='fused':
                for a in range(N):
                    product=1.
                    for b in range(a,N):
                        product*=gain_list[b]
                        products.append(dict(N=N,visible_m=vis,seed=seed,
                                             epsilon_ref_m=epsilon,start=a+1,
                                             end=b+1,product=product))
    out=pd.DataFrame(rows);pp=pd.DataFrame(products)
    out.to_csv(D/f'{output_prefix}_preview_results.csv',index=False)
    pp.to_csv(D/f'{output_prefix}_all_interval_products.csv',index=False)
    print(out.groupby(['N','visible_m','epsilon_ref_m','method'])[
        ['nominal_preview_m','admissible_preview_m','far_30m_error_m',
         'physical_gain','model_valid','age_valid']].mean().round(3).to_string())
    print('max all interval product',pp['product'].max())
    return out

if __name__=='__main__':run()
