"""Generate numerical LaTeX tables directly from frozen CSV results."""
from pathlib import Path
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'data';T=ROOT/'tables';T.mkdir(exist_ok=True)

def save(frame,name,formatters=None):
    def esc(v):
        return str(v).replace('_',r'\_').replace('%',r'\%').replace('&',r'\&')
    lines=[r'\begin{tabular}{'+'l'*len(frame.columns)+'}',r'\toprule',
           ' & '.join(esc(c) for c in frame.columns)+r'\\',r'\midrule']
    for row in frame.itertuples(index=False,name=None):
        cells=[]
        for col,val in zip(frame.columns,row):
            if pd.isna(val):cells.append('--')
            elif formatters and col in formatters:cells.append(esc(formatters[col](val)))
            else:cells.append(esc(val))
        lines.append(' & '.join(cells)+r'\\')
    lines.extend([r'\bottomrule',r'\end{tabular}'])
    (T/name).write_text('\n'.join(lines)+'\n',encoding='utf-8')

def run():
    c=pd.read_csv(D/'cross_model_transport_audit.csv')
    c=c[(c.sequence=='realized')&(c.p==1)].copy()
    c['switch']=c.source+' to '+c.destination
    c=c[['hop','switch','common_support_m','physical_gain',
         'connector_from_previous','chain_gain','projection_lateral_max_m',
         'projection_field_rms','transport_accepted']]
    c.columns=['Hop','Switch','Support m','Hop gain','Connector','Chain gain',
               'Lateral residual m','Field residual','Accepted']
    save(c,'cross_model.tex',{z:'{:.3f}'.format for z in c.columns if z not in ('Hop','Switch','Accepted')})

    p=pd.read_csv(D/'admissible_preview_results.csv')
    p=p[(p.N==20)&(p.vehicle_index==20)&(p.epsilon_ref_m==.2)]
    p=p.groupby(['visible_m','method'],as_index=False)[
        ['nominal_preview_m','admissible_preview_m','far_30m_error_m',
         'model_valid','age_valid']].mean()
    p.method=p.method.map({'local_only':'Local','v2v_only':'V2V',
                            'pose_v2v':'Pose+V2V','fused':'Fused'})
    p.columns=['Visibility m','Method','Nominal m','Admissible m',
               '30-m error m','Model valid','Age valid']
    save(p,'preview.tex',{z:'{:.3f}'.format for z in p.columns if z!='Method'})

    d=pd.read_csv(D/'integrated_dynamic_results.csv')
    d.scenario=d.scenario.str.extract(r'^(D\d)')[0]
    d.method=d.method.map({'local_only':'Local','nominal_fusion':'Nominal',
                            'admissible_fusion':'Admissible'})
    d=d[['scenario','N','method','mean_valid_preview_m',
         'mean_information_admissible_preview_m','lateral_rmse_m',
         'max_lateral_error_m','max_yaw_rate_radps','max_sideslip_rad',
         'steering_saturation_fraction','corridor_violation_fraction',
         'remote_rejected_or_shortened_fraction','computation_s',
         'validity_terminated','termination_time_s']]
    d.columns=['Case','N','Method','Used m','Info m','RMSE m','Max e m',
               'Max yaw rad/s','Max slip rad','Steer sat','Body violation',
               'Remote shortened','CPU s','Terminated','Run s']
    core=d[['Case','N','Method','Used m','Info m','RMSE m','Body violation',
            'Terminated','Run s']]
    vehicle=d[['Case','N','Method','Max e m','Max yaw rad/s','Max slip rad',
               'Steer sat','Remote shortened','CPU s']]
    save(core,'dynamic_core.tex',{z:'{:.3f}'.format for z in core.columns if z not in
         ('Case','N','Method','Terminated')})
    save(vehicle,'dynamic_vehicle.tex',{z:'{:.3f}'.format for z in vehicle.columns if z not in
         ('Case','N','Method')})
    print('generated tables')

if __name__=='__main__':run()
