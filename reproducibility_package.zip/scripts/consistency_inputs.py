"""Record identical physical road-point/V2V samples for Python and MATLAB."""
from pathlib import Path
import numpy as np
import pandas as pd
from reference_estimator import estimate_reference, path_points

D=Path(__file__).resolve().parents[1]/'data'

def run():
    rng=np.random.default_rng(8741)
    pts=[];outs=[]
    specs=[]
    for vis in (8.,12.,15.,30.):
        for source,target in (('M1','M2'),('M2','M3'),('M3','M4'),('M4','M1')):
            specs.append((vis,source,target,.2,0.))
    specs += [(15.,'M2','M4',e,a) for e,a in ((.1,0.),(.2,.6),(.5,.9))]
    specs += [(30.,'M1','M3',.2,0.),(30.,'M3','M4',.2,0.)]
    dims={'M1':1,'M2':2,'M3':3,'M4':4}
    for cid,(vis,source,target,eps,age) in enumerate(specs,1):
        s=np.linspace(0,vis,16)
        r=np.linspace(0,30,16)
        lc=np.linspace(.004,.008,dims[target])
        if cid==20:lc=np.array([.01733624,-.0297784,.04014311])
        if cid==21:lc=np.array([.03955623,-.05322731,.05270883,-.02065293])
        rc=np.linspace(.004,.008,dims[source])
        local=np.column_stack([s,.02+.01*s+path_points(s,30.,target,lc)+rng.normal(0,.004,len(s))])
        remote=np.column_stack([r,.015+.009*r+path_points(r,30.,source,rc)+rng.normal(0,.004,len(r))])
        for kind,data in (('local',local),('remote',remote)):
            for x,y in data:
                pts.append(dict(case_id=cid,kind=kind,x_m=x,y_m=y,age_s=age,epsilon_ref_m=eps))
        result=estimate_reference(local,remote,age,'admissible_fusion',eps)
        outs.append(dict(case_id=cid,model=result['model'],mu=result['mu'],
                         model_valid=int(result['model_valid']),
                         age_valid=int(result['age_valid']),
                         nominal_m=result['nominal'],admissible_m=result['admissible'],
                         projection_rms_m=result['projection_rms'],
                         offset_m=result['offset'],heading=result['heading'],
                         **{f'c{j+1}':result['coeff'][j] if j<len(result['coeff']) else np.nan
                            for j in range(4)}))
    pd.DataFrame(pts).to_csv(D/'estimator_common_inputs.csv',index=False)
    pd.DataFrame(outs).to_csv(D/'python_estimator_outputs.csv',index=False)
    print(len(specs),'recorded cases')

if __name__=='__main__':run()
