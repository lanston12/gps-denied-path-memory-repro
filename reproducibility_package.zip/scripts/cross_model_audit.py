"""Rectangular physical-gain audit for all realized and deliberate M1--M4 switches."""
from pathlib import Path
import numpy as np
import pandas as pd
from adaptive_models import composite_road, fit, MODELS as OLD_MODELS
from path_model import rot
from reference_estimator import cross_model, local_information, induced, physical_Q

ROOT = Path(__file__).resolve().parents[1]
D = ROOT/'data'


def model_short(name):
    return name.split('_')[0]


def realized_coeff(start, W, model):
    ss, x, y, psi = composite_road()
    s = np.linspace(0, W, max(10, int(W/2)))
    global_s = start+s
    xy = np.column_stack([np.interp(global_s, ss, x), np.interp(global_s, ss, y)])
    origin = np.array([np.interp(start, ss, x), np.interp(start, ss, y)])
    local = (xy-origin)@rot(-np.interp(start, ss, psi)).T
    return fit(s, local, W, model, .01)['coeff']


def one(source, dest, shift, Ws, Wd, coeff, p, label, idx):
    T, Qa, Qb, residual, support = cross_model(source, dest, shift, Ws, Wd)
    # This audit replays adaptive-bank windows fitted from independently
    # observed local points over their selected full window. Partial 8--30 m
    # visibility is audited separately in admissible_preview_experiment.py.
    visible = Wd
    J = local_information(np.linspace(0, visible, 16), Wd, dest)
    Qlocal=physical_Q(Wd,dest,visible)
    A = np.linalg.solve(np.eye(Qb.shape[0])+p*np.linalg.solve(Qlocal, J),
                        np.eye(Qb.shape[0]))
    B = A@T
    gain = induced(B, Qb, Qa)
    # Independent invertible scaling in the two coefficient spaces.
    Sa = np.diag(np.geomspace(.001, 1000, len(coeff)))
    Sb = np.diag(np.geomspace(1000, .001, Qb.shape[0]))
    gain_rescaled = induced(Sb@B@np.linalg.inv(Sa),
                            np.linalg.inv(Sb).T@Qb@np.linalg.inv(Sb),
                            np.linalg.inv(Sa).T@Qa@np.linalg.inv(Sa))
    proj = residual@coeff
    n = residual.shape[0]//3
    return dict(sequence=label, hop=idx, source=source, destination=dest,
                source_dim=len(coeff), destination_dim=Qb.shape[0],
                shift_m=shift, source_window_m=Ws, destination_window_m=Wd,
                common_support_m=support, p=p, physical_gain=gain,
                basis_invariance_error=abs(gain-gain_rescaled),
                projection_field_rms=float(np.linalg.norm(proj)/np.sqrt(n)),
                projection_lateral_max_m=float(np.max(np.abs(proj[:n]))*.2),
                destination_information_min=float(np.linalg.eigvalsh(
                    np.linalg.inv(np.linalg.cholesky(Qb).T).T @ J @
                    np.linalg.inv(np.linalg.cholesky(Qb).T))[0]))


def run():
    selected = pd.read_csv(D/'adaptive_model_selection.csv').sort_values('start_m')
    rows=[]
    for p in [1., 10., 100.]:
        for i in range(len(selected)-1):
            a,b=selected.iloc[i],selected.iloc[i+1]
            coeff=realized_coeff(a.start_m,a.W_m,a.model)
            rows.append(one(model_short(a.model),model_short(b.model),
                            b.start_m-a.start_m,a.W_m,b.W_m,coeff,p,'realized',i+1))
        idx=0
        for a in ('M1','M2','M3','M4'):
            for b in ('M1','M2','M3','M4'):
                idx+=1
                coeff=np.linspace(.002,.008,dict(M1=1,M2=2,M3=3,M4=4)[a])
                rows.append(one(a,b,2.5,30.,30.,coeff,p,'pair_test',idx))
        model_chain=('M1','M2','M4','M3','M1','M4','M2','M3')
        for i,(a,b) in enumerate(zip(model_chain[:-1],model_chain[1:]),1):
            coeff=np.linspace(.002,.008,dict(M1=1,M2=2,M3=3,M4=4)[a])
            rows.append(one(a,b,0.,30.,30.,coeff,p,'deliberate_chain',i))
    out=pd.DataFrame(rows)
    out['connector_from_previous']=np.nan
    out['chain_gain']=np.nan
    out['transport_accepted']=np.nan
    out['max_contiguous_product_in_sequence']=np.nan
    out['max_gated_product_in_sequence']=np.nan
    interval_rows=[]
    for (sequence,p),g in out[out.sequence!='pair_test'].groupby(['sequence','p']):
        g=g.sort_values('hop')
        gains=g.physical_gain.to_numpy()
        connectors=np.ones(len(g))
        for k in range(1,len(g)):
            previous,current=g.iloc[k-1],g.iloc[k]
            if previous.destination!=current.source:
                raise AssertionError('model chain is not dimension-compatible')
            _,_,Qprevious,_,_=cross_model(previous.source,previous.destination,
                previous.shift_m,previous.source_window_m,previous.destination_window_m)
            _,Qnext,_,_,_=cross_model(current.source,current.destination,
                current.shift_m,current.source_window_m,current.destination_window_m)
            connectors[k]=induced(np.eye(Qnext.shape[0]),Qnext,Qprevious)
        chain_gains=gains*connectors
        # Allocate half of the 0.2-m reference-quality specification to the
        # projection term; the remainder is available for sensor/age error.
        accepted=((chain_gains<=.95)&
                  (g.projection_lateral_max_m.to_numpy()<=.10)&
                  (g.projection_field_rms.to_numpy()<=1.))
        gated=np.where(accepted,chain_gains,0.)
        products=[];gated_products=[]
        for j in range(len(g)):
            product=1.;gated_product=1.
            for k in range(j,len(g)):
                factor=gains[k] if k==j else connectors[k]*gains[k]
                product*=factor
                gated_product*=factor if accepted[k] else 0.
                products.append(product)
                gated_products.append(gated_product)
                interval_rows.append(dict(sequence=sequence,p=p,start_hop=j+1,
                                          end_hop=k+1,raw_product=product,
                                          gated_product=gated_product))
        out.loc[g.index,'connector_from_previous']=connectors
        out.loc[g.index,'chain_gain']=chain_gains
        out.loc[g.index,'transport_accepted']=accepted.astype(int)
        out.loc[g.index,'max_contiguous_product_in_sequence']=max(products)
        out.loc[g.index,'max_gated_product_in_sequence']=max(gated_products)
    out.to_csv(D/'cross_model_transport_audit.csv',index=False)
    pd.DataFrame(interval_rows).to_csv(D/'cross_model_interval_products.csv',index=False)
    print(out.groupby(['sequence','p'])[['physical_gain','projection_lateral_max_m',
             'max_contiguous_product_in_sequence']].agg(['max','mean']).to_string())
    print('max invariance error',out.basis_invariance_error.max())
    return out


if __name__=='__main__':
    run()
