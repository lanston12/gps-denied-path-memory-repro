"""Additional path-shape stress tests: composite road, bias, observability map."""
from pathlib import Path
import math
import numpy as np
import pandas as pd
from scipy.integrate import cumulative_trapezoid

from path_model import fit_road_shape, observed_points, rot, shape_information, _residual_and_jac

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"


def composite_curvature(s):
    s = np.asarray(s)
    return np.select(
        [s < 10, s < 30, s < 50, s <= 80],
        [0, .012 * (s - 10) / 20, .012,
         .012 * np.cos(2 * np.pi * (s - 50) / 30)], default=0.0)


def composite_road():
    ss = np.linspace(0, 80, 8001)
    k = composite_curvature(ss)
    psi = cumulative_trapezoid(k, ss, initial=0)
    x = cumulative_trapezoid(np.cos(psi), ss, initial=0)
    y = cumulative_trapezoid(np.sin(psi), ss, initial=0)
    rows = []
    for start, W in [(0, 14), (12, 14), (25, 14), (32, 14),
                     (44, 14), (51, 14), (64, 14), (10, 30), (35, 30), (49, 30)]:
        stations = np.linspace(start, start + W, 16)
        origin = np.array([np.interp(start, ss, x), np.interp(start, ss, y)])
        xy = np.stack([np.interp(stations, ss, x), np.interp(stations, ss, y)], 1)
        local = (xy - origin) @ rot(-np.interp(start, ss, psi)).T
        fit = fit_road_shape(stations - start, local, W, .01)
        q = fit["pose"]
        from path_model import curve_and_shape_jac
        predicted, _ = curve_and_shape_jac(stations - start, fit["coeff"], W)
        predicted = predicted @ rot(q[2]).T + q[:2]
        model_residual = np.linalg.norm(predicted - local, axis=1)
        rows.append({"start_m": start, "window_m": W,
                     "curvature_min_1pm": float(np.min(composite_curvature(stations))),
                     "curvature_max_1pm": float(np.max(composite_curvature(stations))),
                     "fit_k0_1pm": fit["coeff"][0], "fit_k1_1pm": fit["coeff"][1],
                     "max_model_residual_m": float(model_residual.max()),
                     "rms_model_residual_m": float(np.sqrt(np.mean(model_residual**2))),
                     "mu_eff_assuming_1cm_noise": fit["mu"]})
    out = pd.DataFrame(rows)
    out.to_csv(DATA / "composite_road_results.csv", index=False)
    return out


def bias_sweep():
    rows = []
    true = np.array([.006, .002])
    for W, eps in [(14., .03), (30., .01)]:
        for bias in [0., .01, .03, .10]:
            for trial in range(16):
                rng = np.random.default_rng(8721 + trial + int(W) * 100)
                theta = rng.uniform(-math.pi, math.pi)
                s, obs = observed_points(true, W, 16, rng.uniform(-10, 10, 2),
                                         theta, rng, eps)
                # Coherent lateral calibration/road-edge bias, omitted from fit contract.
                obs += np.stack([np.zeros_like(s), bias * (s / W)**2], 1) @ rot(theta).T
                fit = fit_road_shape(s, obs, W, eps)
                err = np.linalg.norm(fit["coeff"] - true)
                rows.append({"window_m": W, "noise_limit_m": eps,
                             "systematic_lateral_bias_m": bias, "trial": trial,
                             "k0_error_1pm": fit["coeff"][0] - true[0],
                             "k1_error_1pm": fit["coeff"][1] - true[1],
                             "shape_error_norm_1pm": err,
                             "local_screen_1pm": fit["local_bound_screen"],
                             "screen_covered": err <= fit["local_bound_screen"],
                             "mu_eff": fit["mu"]})
    out = pd.DataFrame(rows)
    out.to_csv(DATA / "noise_bias_sweep.csv", index=False)
    return out


def observability_map():
    rows = []
    for W in [10., 14., 20., 30., 40.]:
        s = np.linspace(0, W, 16)
        for k1 in np.linspace(-.02, .02, 21):
            q = np.array([0., 0., 0., .006, k1])
            _, jac = _residual_and_jac(q, s, np.zeros((len(s), 2)), W)
            _, mu, smin, _ = shape_information(jac, .01 / np.sqrt(3))
            rows.append({"window_m": W, "k1_1pm": k1,
                         "mu_eff": mu, "shape_smin_m": smin})
    out = pd.DataFrame(rows)
    out.to_csv(DATA / "observability_map.csv", index=False)
    return out


if __name__ == "__main__":
    c = composite_road()
    b = bias_sweep()
    m = observability_map()
    print("composite max residual:", c.max_model_residual_m.max())
    print(b.groupby(["window_m", "systematic_lateral_bias_m"])
          [["shape_error_norm_1pm", "screen_covered"]].mean().to_string())
    print("map mu range:", m.mu_eff.min(), m.mu_eff.max())
