"""Physical path metric, basis invariance, and matrix-prior weight sweep."""
from pathlib import Path
import numpy as np
import pandas as pd
from path_model import curve_and_shape_jac, station_map

D = Path(__file__).resolve().parents[1] / "data"
HOPS = pd.read_csv(D / "hop_parameters.csv")
SCALES = [.001, .01, .1, 1., 10., 100., 1000.]
P_VALUES = np.logspace(-4, 4, 17)
Q_WEIGHTS = {"lateral_scale_m":.2, "heading_scale_rad":.02,
             "curvature_scale_1pm":.002}

def physical_Q(coeff, W, scales=(.2,.02,.002)):
    s = np.linspace(0, W, 101)
    _, jac = curve_and_shape_jac(s, np.asarray(coeff, float), W)
    psi = coeff[0]*s + coeff[1]*s*s/(2*W)
    normal = np.stack((-np.sin(psi), np.cos(psi)), 1)
    jy = np.einsum("na,nab->nb", normal, jac)
    jp = np.stack((s, s*s/(2*W)), 1)
    jk = np.stack((np.ones_like(s), s/W), 1)
    z = np.stack((jy/scales[0], jp/scales[1], jk/scales[2]), 1)
    # Unitless mean-square path-relative metric over the declared window.
    Qs = np.einsum("nac,nad->ncd", z, z)
    Q = np.trapz(Qs, s, axis=0) / W
    return .5*(Q+Q.T)

def qnorm(v,Q):
    return float(np.sqrt(max(0,v @ Q @ v)))

def induced(M,Qout,Qin):
    Cout = np.linalg.cholesky(Qout).T
    Cin = np.linalg.cholesky(Qin).T
    return float(np.linalg.svd(Cout @ M @ np.linalg.inv(Cin),
                               compute_uv=False)[0])

def matrix_A(P,J):
    return np.linalg.solve(np.eye(2)+P@J,np.eye(2))

def per_hop(row,p,prevQ=None):
    x = np.array([row.true_k0_1pm,row.true_k1_1pm])
    W = row.window_m
    Q = physical_Q(x,W)
    if prevQ is None:
        xp = np.array([row.true_k0_1pm-row.true_k1_1pm*2.5/W,
                       row.true_k1_1pm])
        prevQ = physical_Q(xp,W)
    J = np.array([[row.J_00,row.J_01],[row.J_01,row.J_11]])
    F = station_map((2.5+row.station_error_m)/W)
    P = p*np.linalg.inv(Q)
    A = matrix_A(P,J)
    return induced(A@F,Q,prevQ), A, F, Q, prevQ, J, P

def rescaling_test():
    sample = HOPS[(HOPS.regime=="informative") & (HOPS.N==20)].iloc[0]
    rows=[]
    for p in [.01,1.,100.]:
        base, A,F,Q,Qp,J,P = per_hop(sample,p)
        for scale in SCALES:
            S = np.diag([scale,1/scale])
            Si=np.linalg.inv(S)
            Qb=Si.T@Q@Si
            Qpb=Si.T@Qp@Si
            Jb=Si.T@J@Si
            Fb=S@F@Si
            Pb=S@P@S.T
            Ab=matrix_A(Pb,Jb)
            consistent=induced(Ab@Fb,Qb,Qpb)
            # Deliberately change estimator: preserve numerical scalar prior.
            Ab_bad=matrix_A(p*np.eye(2),Jb)
            inconsistent=induced(Ab_bad@Fb,Qb,Qpb)
            rows.append({"p":p,"S_first_diagonal":scale,
                         "physical_gain_original":base,
                         "physical_gain_consistent":consistent,
                         "absolute_invariance_error":abs(consistent-base),
                         "physical_gain_inconsistent":inconsistent})
    out=pd.DataFrame(rows)
    out.to_csv(D/"basis_rescaling.csv",index=False)
    return out

def replay_weight_sweep():
    rows=[]
    for regime in ["informative","marginal","unobserved"]:
        trialset=HOPS[(HOPS.regime==regime)&(HOPS.N==20)]
        for p in P_VALUES:
            for seed,g in trialset.groupby("seed"):
                g=g.sort_values("vehicle_index")
                first=g.iloc[0]
                est=np.array([first.initial_estimate_k0_1pm,
                              first.initial_estimate_k1_1pm])
                prevtrue=np.array([first.true_k0_1pm-first.true_k1_1pm*2.5/first.window_m,
                                   first.true_k1_1pm])
                gains=[]; inherited=[]; localterms=[]; errors=[]
                for r in g.itertuples():
                    gain,A,F,Q,Qp,J,P=per_hop(r,p,physical_Q(prevtrue,r.window_m))
                    true=np.array([r.true_k0_1pm,r.true_k1_1pm])
                    z=np.array([r.local_estimate_k0_1pm,r.local_estimate_k1_1pm])
                    geom=np.array([true[0]**2*r.geometry_offset_error_m,
                                   true[0]*true[1]*r.geometry_offset_error_m])
                    olderr=est-prevtrue
                    prior=F@est+geom
                    est=A@prior+(np.eye(2)-A)@z
                    gains.append(gain)
                    inherited.append(qnorm(A@F@olderr,Q))
                    localterms.append(qnorm((np.eye(2)-A)@(z-true),Q))
                    errors.append(qnorm(est-true,Q))
                    prevtrue=true
                pathtrue,_=curve_and_shape_jac(np.array([first.window_m]),
                                               true,first.window_m)
                pathest,_=curve_and_shape_jac(np.array([first.window_m]),
                                              est,first.window_m)
                rows.append({"regime":regime,"N":20,"seed":seed,"p":p,
                             "gamma_phys_max":max(gains),
                             "gamma_phys_median":np.median(gains),
                             "max_all_interval_product":max(
                                 np.prod(gains[j:i]) for j in range(20)
                                 for i in range(j+1,21)),
                             "metric_error_rms":np.sqrt(np.mean(np.square(errors))),
                             "inherited_component_mean":np.mean(inherited),
                             "local_noise_component_mean":np.mean(localterms),
                             "end_path_error_m":np.linalg.norm(pathest-pathtrue)})
    out=pd.DataFrame(rows)
    out.to_csv(D/"regularization_sweep.csv",index=False)
    return out

if __name__=="__main__":
    r=rescaling_test()
    w=replay_weight_sweep()
    print("max invariant error",r.absolute_invariance_error.max())
    print(w.groupby(["regime","p"])[["gamma_phys_max","end_path_error_m",
                                   "local_noise_component_mean"]].mean().to_string())
