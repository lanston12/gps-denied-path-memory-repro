"""Declared physical-comparison-scale sensitivity for partial visibility."""
from pathlib import Path
import itertools
import numpy as np
import pandas as pd
from metric_analysis import physical_Q,matrix_A,induced
from path_model import station_map
D=Path(__file__).resolve().parents[1]/"data"
x=pd.read_csv(D/"partial_visibility_results.csv")
g=x[(x.visible_m==15)&(x.p==1)&(x.method=="fused")]
rows=[]
for scales in itertools.product([.1,.2,.4],[.01,.02,.04],[.001,.002,.004]):
    gains=[]
    for r in g.itertuples():
        true=np.array([r.true_k0_1pm,r.true_k1_1pm])
        prev=np.array([true[0]-true[1]*2.5/30,true[1]])
        Q=physical_Q(true,30,scales)
        Qp=physical_Q(prev,30,scales)
        J=np.array([[r.J_00,r.J_01],[r.J_01,r.J_11]])
        A=matrix_A(np.linalg.inv(Q),J)
        F=station_map((2.5+r.station_error_m)/30)
        gains.append(induced(A@F,Q,Qp))
    rows.append({"lateral_scale_m":scales[0],
                 "heading_scale_rad":scales[1],
                 "curvature_scale_1pm":scales[2],
                 "max_physical_gain":max(gains),
                 "median_physical_gain":np.median(gains),
                 "all_hops_contractive":max(gains)<1})
out=pd.DataFrame(rows)
out.to_csv(D/"metric_scale_sensitivity.csv",index=False)
print("contractive choices",out.all_hops_contractive.sum(),"/",len(out))
print("gain range",out.max_physical_gain.min(),out.max_physical_gain.max())
print(out[~out.all_hops_contractive].to_string(index=False))
