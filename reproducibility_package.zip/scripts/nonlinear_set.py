"""Nonlinear bounded-error shape set via SE(2)-eliminated Procrustes B&B.

The returned union of boxes is an outer set if curve integration is exact.
Numerical quadrature and floating-point tolerances are separately audited.
"""
from pathlib import Path
import heapq
import numpy as np
import pandas as pd
from path_model import curve_and_shape_jac, observed_points, fit_road_shape

D=Path(__file__).resolve().parents[1]/"data"

def rotation_eliminated_residual(coeff,s,obs,W):
    points,_=curve_and_shape_jac(s,np.asarray(coeff),W)
    P=points-points.mean(0)
    Z=obs-obs.mean(0)
    U,_,Vt=np.linalg.svd(P.T@Z)
    R=U@np.diag([1.,np.linalg.det(U@Vt)])@Vt
    return float(np.linalg.norm(P@R-Z))

def global_lipschitz(s,W):
    # Exact bound on the stacked path-point Jacobian of affine curvature.
    return float(np.sqrt(np.sum((s*s/2)**2+(s**3/(6*W))**2)))

def outer_boxes(s,obs,W,eps,prior_bounds=(-.005,.015,-.01,.01),
                width_target=1e-4,max_evals=20000):
    threshold=np.sqrt(2*len(s))*eps+1e-8
    L=global_lipschitz(s,W)
    heap=[]
    counter=0
    def push(box):
        nonlocal counter
        lo=np.array([box[0],box[2]])
        hi=np.array([box[1],box[3]])
        center=(lo+hi)/2
        r=np.linalg.norm((hi-lo)/2)
        f=rotation_eliminated_residual(center,s,obs,W)
        if f-L*r <= threshold:
            heapq.heappush(heap,(-max(hi-lo),counter,box,f))
            counter+=1
    push(tuple(prior_bounds))
    terminal=[]
    while heap and counter<max_evals:
        negw,_,box,f=heapq.heappop(heap)
        if -negw<=width_target:
            terminal.append(box)
            continue
        widths=np.array([box[1]-box[0],box[3]-box[2]])
        k=int(np.argmax(widths))
        mid=(box[2*k]+box[2*k+1])/2
        a=list(box);b=list(box)
        a[2*k+1]=mid;b[2*k]=mid
        push(tuple(a));push(tuple(b))
    terminal += [item[2] for item in heap]
    if not terminal:
        return {"status":"empty","evaluations":counter}
    bounds=np.array(terminal)
    outer=np.array([bounds[:,0].min(),bounds[:,1].max(),
                    bounds[:,2].min(),bounds[:,3].max()])
    status="resolved" if not heap else "budget_limited_outer"
    return {"status":status,"evaluations":counter,"boxes":len(terminal),
            "outer":outer,"box_list":terminal,"lipschitz":L,"threshold":threshold}

def run():
    rng=np.random.default_rng(905)
    rows=[]
    for W,n,eps in [(30.,16,.01),(14.,10,.03)]:
        for trial in range(4):
            true=np.array([rng.uniform(.003,.008),rng.uniform(-.002,.003)])
            theta=rng.uniform(-np.pi,np.pi)
            s,obs=observed_points(true,W,n,rng.uniform(-5,5,2),theta,rng,eps)
            fit=fit_road_shape(s,obs,W,eps)
            bound=outer_boxes(s,obs,W,eps)
            if "outer" in bound:
                b=bound["outer"]
                center=fit["coeff"]
                corners=np.array([[b[0],b[2]],[b[0],b[3]],
                                  [b[1],b[2]],[b[1],b[3]]])
                r=max(np.linalg.norm(corners-center,axis=1))
                # Exact global coefficient-to-position conversion for the
                # affine basis, conditional on the enclosing coefficient box.
                factor=np.hypot(W*W/2,W*W/6)
                nonlinear_path_screen=r*factor
                old_path_screen=fit["local_bound_screen"]*factor
                ptruth,_=curve_and_shape_jac(np.array([W]),true,W)
                pest,_=curve_and_shape_jac(np.array([W]),center,W)
                union_screen=0.
                for box in bound["box_list"]:
                    mid=np.array([(box[0]+box[1])/2,(box[2]+box[3])/2])
                    half=np.array([(box[1]-box[0])/2,(box[3]-box[2])/2])
                    pmid,_=curve_and_shape_jac(np.array([W]),mid,W)
                    union_screen=max(union_screen,
                                     float(np.linalg.norm(pmid-pest))+factor*np.linalg.norm(half))
                err=np.linalg.norm(ptruth-pest)
                contains=(b[0]<=true[0]<=b[1] and b[2]<=true[1]<=b[3])
            else:
                r=nonlinear_path_screen=union_screen=old_path_screen=err=np.nan
                contains=False
            rows.append({"W_m":W,"n_points":n,"eps_m":eps,"trial":trial,
                         "true_k0":true[0],"true_k1":true[1],
                         "fit_k0":fit["coeff"][0],"fit_k1":fit["coeff"][1],
                         "status":bound["status"],"evals":bound["evaluations"],
                         "boxes":bound.get("boxes",0),
                         "outer_coeff_radius_1pm":r,
                         "old_linear_path_screen_m":old_path_screen,
                         "nonlinear_outer_path_screen_m":nonlinear_path_screen,
                         "nonlinear_union_path_screen_m":union_screen,
                         "actual_end_error_m":err,
                         "true_inside_outer":contains})
        print("completed",W,flush=True)
    out=pd.DataFrame(rows)
    out.to_csv(D/"nonlinear_set_results.csv",index=False)
    print(out.groupby("W_m")[["old_linear_path_screen_m",
                              "nonlinear_outer_path_screen_m",
                              "actual_end_error_m","evals"]].mean())

def run_partial():
    rng=np.random.default_rng(18014)
    rows=[]
    W=30.
    for visible in [8.,12.,15.,30.]:
        for trial in range(2):
            true=np.array([rng.uniform(.003,.008),rng.uniform(-.002,.003)])
            s=np.linspace(0,visible,16)
            p,_=curve_and_shape_jac(s,true,W)
            theta=rng.uniform(-np.pi,np.pi)
            from path_model import rot
            obs=p@rot(theta).T+rng.uniform(-5,5,2)+rng.uniform(-.01,.01,p.shape)
            fit=fit_road_shape(s,obs,W,.01)
            bound=outer_boxes(s,obs,W,.01,max_evals=20000)
            pest,_=curve_and_shape_jac(np.array([W]),fit["coeff"],W)
            ptruth,_=curve_and_shape_jac(np.array([W]),true,W)
            factor=np.hypot(W*W/2,W*W/6)
            union=np.nan
            if "box_list" in bound:
                union=0.
                for box in bound["box_list"]:
                    mid=np.array([(box[0]+box[1])/2,(box[2]+box[3])/2])
                    half=np.array([(box[1]-box[0])/2,(box[3]-box[2])/2])
                    pmid,_=curve_and_shape_jac(np.array([W]),mid,W)
                    union=max(union,float(np.linalg.norm(pmid-pest))+
                              factor*np.linalg.norm(half))
            rows.append({"visible_m":visible,"desired_preview_m":W,"trial":trial,
                         "status":bound["status"],"evals":bound["evaluations"],
                         "nonlinear_union_far_screen_m":union,
                         "actual_far_error_m":float(np.linalg.norm(ptruth-pest))})
        print("partial completed",visible,flush=True)
    out=pd.DataFrame(rows)
    out.to_csv(D/"partial_nonlinear_set.csv",index=False)
    print(out.groupby("visible_m")[["nonlinear_union_far_screen_m",
                                    "actual_far_error_m"]].mean())

if __name__=="__main__":
    import sys
    if len(sys.argv)>1 and sys.argv[1]=="partial":
        run_partial()
    else:
        run()
