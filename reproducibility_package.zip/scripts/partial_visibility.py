"""Causal estimator-only partial-visibility comparison; no vehicle truth feedback."""
from pathlib import Path
import numpy as np
import pandas as pd
from path_model import curve_and_shape_jac,fit_road_shape,rot,station_map
from metric_analysis import physical_Q,induced,matrix_A

D=Path(__file__).resolve().parents[1]/"data"
W=30.
P_LIST=[.001,.01,.1,1.,10.,100.]
VIS_LIST=[8.,12.,15.,30.]
SEEDS=range(16)

def road_points(true,visible,rng):
    s=np.linspace(0,visible,16)
    p,_=curve_and_shape_jac(s,true,W)
    theta=rng.uniform(-np.pi,np.pi)
    translation=rng.uniform(-10,10,2)
    obs=p@rot(theta).T+translation+rng.uniform(-.01,.01,p.shape)
    return s,obs

def endpoint_error(true,estimate,station):
    a,_=curve_and_shape_jac(np.array([station]),true,W)
    b,_=curve_and_shape_jac(np.array([station]),estimate,W)
    return float(np.linalg.norm(a-b))

def run():
    rows=[]
    for visible in VIS_LIST:
        for seed in SEEDS:
            rng=np.random.default_rng(78620+seed)
            g0=rng.uniform(.003,.008);g1=rng.uniform(-.002,.003)
            initial_true=np.array([g0,g1])
            initial_est=initial_true+rng.uniform(-.00015,.00015,2)
            # Same observations and injected perturbations for every method/p.
            data=[]
            for i in range(1,21):
                true=np.array([g0+g1*i*2.5/W,g1])
                s,obs=road_points(true,visible,rng)
                f=fit_road_shape(s,obs,W,.01)
                shift=rng.uniform(-.08,.08)
                geom=np.array([true[0]**2, true[0]*true[1]])*rng.uniform(-.1,.1)
                data.append((true,f["coeff"],f["J"],shift,geom))
            for p in P_LIST:
                previous={"v2v":initial_est.copy(),"pose_v2v":initial_est.copy(),
                          "fused":initial_est.copy()}
                trueprev=initial_true
                gamma=[]
                for i,(true,z,J,shift,geom) in enumerate(data,1):
                    F=station_map((2.5+shift)/W)
                    Q=physical_Q(true,W)
                    Qprev=physical_Q(trueprev,W)
                    prior=F@previous["fused"]+geom
                    A=matrix_A(p*np.linalg.inv(Q),J)
                    fused=A@prior+(np.eye(2)-A)@z
                    gamma.append(induced(A@F,Q,Qprev))
                    v2v=F@previous["v2v"]+geom
                    # Pose anchor only changes embedding, not the two shape modes.
                    pose_v2v=F@previous["pose_v2v"]+geom
                    for method,est,preview in [
                        ("local_only",z,visible),("v2v_only",v2v,W),
                        ("pose_v2v",pose_v2v,W),("fused",fused,W)]:
                        rows.append({"visible_m":visible,"preview_goal_m":W,
                                     "N":20,"seed":seed,"p":p,"vehicle_index":i,
                                     "method":method,"valid_preview_m":preview,
                                     "true_k0_1pm":true[0],"true_k1_1pm":true[1],
                                     "station_error_m":shift,
                                     "J_00":J[0,0],"J_01":J[0,1],"J_11":J[1,1],
                                     "error_at_valid_preview_m":
                                     endpoint_error(true,est,preview),
                                     "far_30m_error_m":endpoint_error(true,est,W)
                                     if preview==W else np.nan,
                                     "mu_coeff":max(0,float(np.linalg.eigvalsh(J)[0])),
                                     "gamma_phys":gamma[-1] if method=="fused" else
                                     induced(F,Q,Qprev)})
                    previous={"v2v":v2v,"pose_v2v":pose_v2v,"fused":fused}
                    trueprev=true
    out=pd.DataFrame(rows)
    out.to_csv(D/"partial_visibility_results.csv",index=False)
    print(out[(out.vehicle_index==20)&(out.method.isin(["fused","v2v_only","local_only"]))]
          .groupby(["visible_m","p","method"])[["valid_preview_m",
                                                "error_at_valid_preview_m",
                                                "far_30m_error_m",
                                                "gamma_phys"]].mean().round(4).to_string())
    return out

if __name__=="__main__":
    run()
