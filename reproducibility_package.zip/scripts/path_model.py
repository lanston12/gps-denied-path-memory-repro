"""Finite-window affine-curvature path model and road-point estimator.

All algorithm inputs are in independently initialized local frames. The
global curve is used only to generate synthetic sensor data and evaluate
errors. CarSim is not used.
"""
from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from scipy.optimize import least_squares


GL_X, GL_W = np.polynomial.legendre.leggauss(20)


def rot(theta: float) -> NDArray[np.float64]:
    c, s = np.cos(theta), np.sin(theta)
    return np.array([[c, -s], [s, c]], dtype=float)


def curve_and_shape_jac(
    s: NDArray[np.float64], coeff: NDArray[np.float64], window: float
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Integrate kappa(u)=k0+k1*u, u=s/window, from a zero pose at s=0.

    Returns points (m,2) and analytic derivatives w.r.t. [k0,k1] (m,2,2).
    The Gauss-Legendre quadrature is numerical, with 20 nodes per integral.
    """
    ss = np.asarray(s, dtype=float).reshape(-1)
    tau = 0.5 * ss[:, None] * (GL_X[None, :] + 1.0)
    wt = 0.5 * ss[:, None] * GL_W[None, :]
    phase = coeff[0] * tau + 0.5 * coeff[1] * tau**2 / window
    tangent = np.stack((np.cos(phase), np.sin(phase)), axis=-1)
    normal = np.stack((-np.sin(phase), np.cos(phase)), axis=-1)
    point = np.sum(wt[..., None] * tangent, axis=1)
    jac = np.empty((len(ss), 2, 2), dtype=float)
    jac[:, :, 0] = np.sum(wt[..., None] * tau[..., None] * normal, axis=1)
    jac[:, :, 1] = np.sum(
        wt[..., None] * (tau**2 / (2.0 * window))[..., None] * normal,
        axis=1,
    )
    return point, jac


def observed_points(
    coeff: NDArray[np.float64],
    window: float,
    n_points: int,
    translation: NDArray[np.float64],
    theta: float,
    rng: np.random.Generator,
    error_limit: float,
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    """Camera/LiDAR road-centerline point returns in one private local frame.

    The bounded uniform coordinate perturbation is an explicit synthetic
    sensor contract. This routine never supplies the random frame transform
    to the estimator.
    """
    s = np.linspace(0.0, window, n_points)
    point, _ = curve_and_shape_jac(s, coeff, window)
    noise = rng.uniform(-error_limit, error_limit, size=point.shape)
    return s, point @ rot(theta).T + translation + noise


def _residual_and_jac(
    q: NDArray[np.float64],
    s: NDArray[np.float64],
    obs: NDArray[np.float64],
    window: float,
) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
    translation = q[:2]
    theta = q[2]
    coeff = q[3:]
    point, shape_jac = curve_and_shape_jac(s, coeff, window)
    R = rot(theta)
    pred = point @ R.T + translation
    jpose = np.empty((len(s), 2, 3), dtype=float)
    jpose[:, :, :2] = np.eye(2)[None, :, :]
    jpose[:, :, 2] = point @ (R @ np.array([[0, -1], [1, 0]])).T
    jshape = np.einsum("ab,nbc->nac", R, shape_jac)
    jac = np.concatenate((jpose, jshape), axis=2).reshape(-1, 5)
    return (pred - obs).reshape(-1), jac


def shape_information(jac: NDArray[np.float64], sigma: float
) -> tuple[NDArray[np.float64], float, float, NDArray[np.float64]]:
    """Schur-complement information after eliminating 3 pose nuisance modes.

    Returns J_eff, its smallest eigenvalue, its unweighted minimum singular
    value, and the projected shape Jacobian. Both curvature coefficients are
    in 1/m, so J_eff has units m^2 for a dimensionless normalized residual.
    """
    G, H = jac[:, :3], jac[:, 3:]
    P = np.eye(len(G)) - G @ np.linalg.pinv(G)
    H_eff = P @ H
    sv = np.linalg.svd(H_eff, compute_uv=False)
    smin = float(sv[-1])
    J = (H_eff.T @ H_eff) / (sigma**2)
    J = 0.5 * (J + J.T)
    mu = float(max(0.0, np.linalg.eigvalsh(J)[0]))
    return J, mu, smin, H_eff


def fit_road_shape(
    s: NDArray[np.float64],
    obs: NDArray[np.float64],
    window: float,
    error_limit: float,
) -> dict:
    """Fit pose nuisance and invariant curvature coefficients jointly."""
    theta0 = float(np.arctan2(*(obs[1] - obs[0])[::-1]))
    start = np.array([obs[0, 0], obs[0, 1], theta0, 0.0, 0.0])
    def residual(q: NDArray[np.float64]) -> NDArray[np.float64]:
        return _residual_and_jac(q, s, obs, window)[0]
    def jacobian(q: NDArray[np.float64]) -> NDArray[np.float64]:
        return _residual_and_jac(q, s, obs, window)[1]
    fit = least_squares(
        residual,
        start,
        jac=jacobian,
        x_scale=np.array([1.0, 1.0, 0.1, 0.002, 0.002]),
        max_nfev=80,
        ftol=1e-10,
        xtol=1e-10,
        gtol=1e-10,
    )
    _, H = _residual_and_jac(fit.x, s, obs, window)
    sigma = error_limit / np.sqrt(3.0) if error_limit > 0 else 1e-9
    J, mu, smin, H_eff = shape_information(H, sigma)
    # Local linear screen, not a verified global nonlinear interval bound.
    local_bound = (
        2.0 * np.sqrt(2 * len(s)) * error_limit / max(smin, 1e-12)
    )
    return {
        "coeff": fit.x[3:].copy(),
        "pose": fit.x[:3].copy(),
        "J": J,
        "mu": mu,
        "smin": smin,
        "local_bound_screen": local_bound,
        "residual_norm": float(np.linalg.norm(fit.fun)),
        "converged": bool(fit.success),
        "nfev": int(fit.nfev),
        "projected_jac": H_eff,
    }


def station_map(delta_over_window: float) -> NDArray[np.float64]:
    """Exact affine-curvature coefficient reparameterization."""
    return np.array([[1.0, delta_over_window], [0.0, 1.0]], dtype=float)


def station_gain(d: float) -> float:
    """Exact spectral norm of [[1,d],[0,1]]."""
    return float(np.linalg.norm(station_map(d), 2))


def registration_jacobian(
    s: NDArray[np.float64], coeff: NDArray[np.float64], window: float
) -> NDArray[np.float64]:
    """Jacobian for known transmitter shape and unknown tx,ty,theta,shift."""
    point, _ = curve_and_shape_jac(s, coeff, window)
    phase = coeff[0] * s + 0.5 * coeff[1] * s**2 / window
    tangent = np.stack((np.cos(phase), np.sin(phase)), axis=-1)
    H = np.empty((len(s), 2, 4), dtype=float)
    H[:, :, :2] = np.eye(2)[None, :, :]
    H[:, :, 2] = np.stack((-point[:, 1], point[:, 0]), axis=1)
    H[:, :, 3] = tangent
    return H.reshape(-1, 4)


def all_products(gamma: NDArray[np.float64]) -> list[tuple[int, int, int, float]]:
    """Every contiguous product, with j=0..N-1 and i=j+1..N."""
    out = []
    N = len(gamma)
    for j in range(N):
        product = 1.0
        for i in range(j + 1, N + 1):
            product *= float(gamma[i - 1])
            out.append((j, i, i - j, product))
    return out
