"""Enumerate every coordinate-invariant physical-gain interval in key regimes."""
from pathlib import Path
import numpy as np
import pandas as pd
D=Path(__file__).resolve().parents[1]/"data"
x=pd.read_csv(D/"partial_visibility_results.csv")
select={(30.,.001):"full_30m_p0.001",
        (15.,1.):"partial_15m_p1",
        (12.,10.):"partial_12m_p10",
        (8.,100.):"partial_8m_p100"}
rows=[]
for (visible,p),name in select.items():
    q=x[(x.visible_m==visible)&(x.p==p)&(x.method=="fused")]
    for seed,g in q.groupby("seed"):
        gains=g.sort_values("vehicle_index").gamma_phys.to_numpy()
        for j in range(len(gains)):
            product=1.
            for i in range(j+1,len(gains)+1):
                product*=gains[i-1]
                rows.append({"condition":name,"visible_m":visible,"p":p,
                             "seed":seed,"start_index":j,"end_index":i,
                             "span":i-j,"product":product})
out=pd.DataFrame(rows)
out.to_csv(D/"physical_gamma_products.csv",index=False)
print(out.groupby("condition")["product"].max().to_string())
