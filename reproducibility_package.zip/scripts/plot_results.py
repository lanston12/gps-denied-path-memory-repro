"""Generate data-backed Figures 3, 4, 4b and 5."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)
plt.rcParams.update({"font.size": 8, "axes.titlesize": 9,
                     "pdf.fonttype": 42, "ps.fonttype": 42})

def save(name):
    plt.savefig(FIG / (name + ".pdf"), bbox_inches="tight")
    plt.savefig(FIG / (name + ".png"), dpi=200, bbox_inches="tight")
    plt.close()

def fig3():
    m = pd.read_csv(DATA / "observability_map.csv")
    c = pd.read_csv(DATA / "composite_road_results.csv")
    r = pd.read_csv(DATA / "registration_singular_values.csv")
    pivot = m.pivot(index="k1_1pm", columns="window_m", values="mu_eff")
    fig, ax = plt.subplots(1, 3, figsize=(9.4, 2.65))
    im = ax[0].imshow(pivot.values, aspect="auto", origin="lower",
                      extent=[8,42,-.021,.021], norm=LogNorm(), cmap="viridis")
    ax[0].set(xlabel="Visible road window W (m)", ylabel="Curvature-slope coefficient (1/m)",
              title="Independent two-mode shape information")
    ax[0].axvline(30, color="white", linestyle="--", linewidth=1.2)
    ax[0].text(31, -.017, r"$W^*=30$ m", color="white", fontsize=7)
    fig.colorbar(im, ax=ax[0], label=r"$\mu_{\rm eff}$ (m$^2$)")
    ax[1].bar(r.path, r.singular_4, color=["#c65b45","#d8a237","#277e98"])
    ax[1].set_yscale("symlog", linthresh=1e-15)
    ax[1].set(ylabel="Smallest registration singular value",
              title="Unknown station shift")
    ax[2].scatter(c.start_m, c.max_model_residual_m, c=c.window_m,
                  cmap="plasma", s=34)
    ax[2].axhline(.01, color="black", linestyle="--", linewidth=1,
                  label="1 cm point-noise limit")
    ax[2].set(xlabel="Composite-road window start (m)",
              ylabel="Max affine-model residual (m)",
              title="Piecewise-road model mismatch")
    ax[2].legend(fontsize=7)
    fig.tight_layout()
    save("fig3_observability")

def fig4():
    s = pd.read_csv(DATA / "scaling_results.csv")
    fig, ax = plt.subplots(2, 2, figsize=(9.4, 5.4))
    colors = {"informative":"#287c87","marginal":"#d38329","unobserved":"#a14255"}
    for panel, N in zip(ax.flat[:3], [5, 10, 20]):
        for regime in colors:
            d = s[(s.regime == regime) & (s.N == N)]
            g = d.groupby("vehicle_index")[["path_end_error_m","path_end_radius_m"]].mean()
            panel.plot(g.index, g.path_end_error_m, color=colors[regime],
                       label=regime + " error")
            panel.plot(g.index, g.path_end_radius_m, "--", color=colors[regime],
                       label=regime + " screen")
        panel.set(yscale="log", xlabel="Follower index",
                  ylabel="End-window path error / screen (m)", title=f"N={N}")
        panel.grid(alpha=.25)
    panel = ax.flat[3]
    for regime in colors:
        d = s[(s.regime == regime) & (s.N == 20)]
        g = d.groupby("vehicle_index")[["inherited_bound_1pm","additive_bound_1pm"]].mean()
        panel.plot(g.index, g.inherited_bound_1pm, color=colors[regime],
                   label=regime + " inherited")
        panel.plot(g.index, g.additive_bound_1pm, "--", color=colors[regime],
                   label=regime + " additive")
    panel.set(yscale="log", xlabel="Follower index",
              ylabel="Coefficient-radius contribution (1/m)",
              title="N=20 screen decomposition")
    panel.grid(alpha=.25)
    fig.legend(*ax.flat[0].get_legend_handles_labels(), loc="lower center",
               ncol=3, fontsize=7, bbox_to_anchor=(.5,-.005))
    fig.tight_layout(rect=[0,.06,1,1])
    save("fig4_reference_scaling")

def fig4b():
    p = pd.read_csv(DATA / "gamma_products.csv")
    fig, ax = plt.subplots(1, 2, figsize=(9.4, 3.0))
    colors = {"informative":"#287c87","marginal":"#d38329","unobserved":"#a14255"}
    for regime in colors:
        d = p[(p.regime == regime) & (p.N == 20)]
        upper = d.groupby("span")["product"].max()
        ax[0].plot(upper.index, upper.values, marker=".", ms=3,
                   color=colors[regime], label=regime)
    ax[0].set_yscale("log")
    ax[0].axhline(1, color="black", lw=.8)
    ax[0].set(xlabel="Contiguous span (hops)", ylabel="Maximum product across intervals/seeds",
              title="All interval products, N=20")
    ax[0].legend()
    d = p[(p.regime == "informative") & (p.N == 20) &
          (p.seed == p.seed.min())]
    mat = np.full((21,21), np.nan)
    for row in d.itertuples():
        mat[row.start_index, row.end_index] = row.product
    im = ax[1].imshow(mat, norm=LogNorm(vmin=1e-14, vmax=1), cmap="viridis",
                      origin="lower", aspect="auto")
    ax[1].set(xlabel="End index", ylabel="Start index",
              title="Every informative interval, one seed")
    fig.colorbar(im, ax=ax[1], label="Contiguous product")
    fig.tight_layout()
    save("fig4b_gamma_products")

def fig5():
    o = pd.read_csv(DATA / "outage_results.csv")
    fig, ax = plt.subplots(2, 1, figsize=(9.4, 4.2), sharex=True,
                           gridspec_kw={"height_ratios":[2,1]})
    ax[0].plot(o.time_s, o.truth_lateral_m, color="black", lw=1.4, label="synthetic truth")
    for mode, color in [("age_valid_memory","#287c87"),
                        ("bounded_local_inference","#d38329")]:
        d = o[o["mode"] == mode]
        ax[0].scatter(d.time_s, d.nominal_lateral_m, s=9, color=color,
                   label=mode.replace("_"," "))
        ax[0].vlines(d.time_s, d.nominal_lateral_m-d.radius_m,
                  d.nominal_lateral_m+d.radius_m, color=color, alpha=.35, lw=.5)
    u = o[o["mode"] == "unavailable_preview"]
    ax[0].axvspan(u.time_s.min(), u.time_s.max(), color="#a14255", alpha=.16,
               label="unavailable preview")
    ax[0].set(ylabel="Lateral path coordinate (m)",
              title="3.2 s message burst loss, 0.8 s memory-age limit")
    ax[0].legend(fontsize=7, ncol=2)
    ax[1].plot(o.time_s, o.message_age_s, color="#5a6880",
               label="message age (s)")
    ax[1].axhline(.8, color="black", ls="--", lw=.8, label="age limit")
    ax2 = ax[1].twinx()
    ax2.step(o.time_s, o.valid_preview_m, color="#287c87", where="mid",
             label="valid preview (m)")
    ax[1].set(xlabel="Time (s)", ylabel="Message age (s)", ylim=(0,3.6))
    ax2.set(ylabel="Valid preview (m)", ylim=(-2,35))
    ax[1].legend(fontsize=7, loc="upper left")
    ax2.legend(fontsize=7, loc="upper right")
    for a in ax:
        a.grid(alpha=.2)
    fig.tight_layout()
    save("fig5_outage_expiry")

if __name__ == "__main__":
    fig3()
    fig4()
    fig4b()
    fig5()
