from pathlib import Path
import pandas as pd, matplotlib.pyplot as plt
p=Path(__file__).resolve().parents[1]
d=pd.read_csv(p/'data/cross_model_transport_audit.csv')
r=d[(d.sequence=='realized')&(d.p==1)].sort_values('hop')
a=d[(d.sequence=='pair_test')&(d.p==1)]
heat=a.pivot(index='source',columns='destination',values='projection_lateral_max_m').loc[['M4','M3','M2','M1'],['M1','M2','M3','M4']]
fig,axs=plt.subplots(1,2,figsize=(10.2,3.2),gridspec_kw={'width_ratios':[1.14,1]})
ax=axs[0];ax2=ax.twinx();h=r.hop.to_numpy();g=r.chain_gain.to_numpy();ok=r.transport_accepted.to_numpy()==1
ax.plot(h,g,color='#275d80',lw=1.5,alpha=.5,label='connector-adjusted gain')
ax.scatter(h[ok],g[ok],c='#12805c',marker='o',s=52,label='accepted',zorder=4)
ax.scatter(h[~ok],g[~ok],c='#b43133',marker='x',s=80,lw=2,label='rejected',zorder=5)
ax.axhline(.95,color='black',ls=':',lw=1,label='gain threshold')
ax2.bar(h,r.projection_lateral_max_m,width=.36,color='#d4a77d',alpha=.55,label='projection residual')
ax.set(xlabel='Realized transition',ylabel='Connector-adjusted gain',xticks=h,ylim=(0,1.65));ax2.set_ylabel('Max lateral projection residual (m)')
ax.legend(fontsize=7,loc='upper left',ncol=2);ax2.set_ylim(0,.17)
im=axs[1].imshow(heat.to_numpy(),origin='upper',cmap='YlOrRd',vmin=0,vmax=.47,aspect='auto')
axs[1].set(xticks=range(4),xticklabels=heat.columns,yticks=range(4),yticklabels=heat.index,xlabel='Destination basis',ylabel='Source basis')
fig.colorbar(im,ax=axs[1],label='Max lateral projection residual (m)',fraction=.048,pad=.04)
fig.tight_layout();fig.savefig(p/'figures/fig5_cross_model_tvt.pdf',bbox_inches='tight');plt.close(fig)
lines=[r'\begin{tabular}{llrrr}',r'\toprule Source & Destination & Gain & Projection max (m) & Field RMS\\',r'\midrule']
for x in a.sort_values(['source','destination']).itertuples():
    lines.append(f'{x.source} & {x.destination} & {x.physical_gain:.3f} & {x.projection_lateral_max_m:.3f} & {x.projection_field_rms:.3f}'+r'\\')
lines += [r'\bottomrule',r'\end{tabular}']
(p/'tables/all_pairs_tvt.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
