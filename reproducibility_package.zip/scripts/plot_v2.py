"""Data-backed v2 figures; no CarSim content."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

R=Path(__file__).resolve().parents[1]
D=R/"data"; F=R/"figures";F.mkdir(exist_ok=True)
plt.rcParams.update({"font.size":8,"axes.titlesize":9,"pdf.fonttype":42})
def save(name):
    plt.savefig(F/(name+".pdf"),bbox_inches="tight")
    plt.savefig(F/(name+".png"),dpi=200,bbox_inches="tight")
    plt.close()

def fig3():
    b=pd.read_csv(D/"adaptive_model_bank.csv")
    s=pd.read_csv(D/"adaptive_model_selection.csv")
    a=b[b.model=="M2_affine"]
    P=a.pivot(index="start_m",columns="W_m",values="mu_phys")
    Rm=a.pivot(index="start_m",columns="W_m",values="max_abs_residual_m")
    fig,ax=plt.subplots(1,3,figsize=(10,3))
    im=ax[0].imshow(P.values,origin="lower",aspect="auto",norm=LogNorm(),
                    extent=[6,32,-2,72],cmap="viridis")
    ax[0].set(xlabel="Visible window (m)",ylabel="Road start (m)",
              title="Affine physical full-mode information")
    fig.colorbar(im,ax=ax[0],label="min eig. in physical metric")
    im=ax[1].imshow(Rm.values,origin="lower",aspect="auto",
                    extent=[6,32,-2,72],cmap="magma",vmin=0,vmax=.1)
    ax[1].set(xlabel="Visible window (m)",title="Affine maximum point residual")
    fig.colorbar(im,ax=ax[1],label="residual (m)")
    ax[2].scatter(s.start_m,s.W_m,c=s.order,cmap="tab10",vmin=1,vmax=4,
                  s=95,edgecolors="black")
    for r in s.itertuples():
        ax[2].text(r.start_m,r.W_m+1.2,"M"+str(r.order),
                   ha="center",fontsize=7)
    ax[2].set(xlabel="Road start (m)",ylabel="Accepted window (m)",
              ylim=(5,35),title="Longest valid window; lowest order")
    for x in ax: x.grid(alpha=.15)
    fig.tight_layout();save("fig3_model_observability")

def fig4():
    x=pd.read_csv(D/"partial_visibility_results.csv")
    p=pd.read_csv(D/"physical_gamma_products.csv")
    r=pd.read_csv(D/"basis_rescaling.csv")
    fig,ax=plt.subplots(1,3,figsize=(10,2.9))
    f=x[x.method=="fused"].groupby(["visible_m","p"]).gamma_phys.max().reset_index()
    for vis,g in f.groupby("visible_m"):
        ax[0].plot(g.p,g.gamma_phys,marker="o",ms=3,label=f"{vis:g} m")
    ax[0].axhline(1,color="black",ls="--",lw=.8)
    ax[0].set(xscale="log",yscale="log",xlabel="Dimensionless matrix-prior p",
              ylabel="Worst physical hop gain",title="Weight / visibility tradeoff")
    ax[0].legend(fontsize=7)
    for name,g in p.groupby("condition"):
        h=g.groupby("span")["product"].max()
        ax[1].plot(h.index,h.values,label=name.replace("_"," "))
    ax[1].set(yscale="log",xlabel="Contiguous span (hops)",
              ylabel="Max product over intervals/seeds",
              title="All-interval physical products")
    ax[1].legend(fontsize=6)
    q=r[r.p==1]
    ax[2].plot(q.S_first_diagonal,q.physical_gain_consistent,"o-",
               label="consistent transform")
    ax[2].plot(q.S_first_diagonal,q.physical_gain_inconsistent,"s--",
               label="scalar prior reused")
    ax[2].set(xscale="log",yscale="log",xlabel="First diagonal of S",
              ylabel="Physical induced gain",title="Basis-rescaling test")
    ax[2].legend(fontsize=7)
    fig.tight_layout();save("fig4_physical_gain")

def fig4b():
    w=pd.read_csv(D/"regularization_sweep.csv")
    fig,ax=plt.subplots(1,2,figsize=(8.5,2.8))
    colors={"informative":"#287c87","marginal":"#d38329",
            "unobserved":"#a14255"}
    for regime,g in w.groupby("regime"):
        m=g.groupby("p")[["gamma_phys_max","metric_error_rms",
                          "local_noise_component_mean"]].mean()
        ax[0].plot(m.index,m.gamma_phys_max,"o-",ms=3,color=colors[regime],
                   label=regime)
        ax[1].plot(m.index,m.metric_error_rms,"o-",ms=3,color=colors[regime],
                   label=regime+" total error")
        ax[1].plot(m.index,m.local_noise_component_mean,"--",color=colors[regime],
                   label=regime+" noise injection")
    ax[0].axhline(1,color="black",ls=":",lw=.8)
    ax[0].set(xscale="log",yscale="log",xlabel="Dimensionless matrix-prior p",
              ylabel="Mean worst physical gain",
              title="Inherited-error contraction")
    ax[1].set(xscale="log",yscale="log",xlabel="Dimensionless matrix-prior p",
              ylabel="Physical-metric error / noise term (dimensionless)",
              title="Noise and total-error tradeoff")
    ax[0].legend(fontsize=7)
    ax[1].legend(fontsize=6,ncol=2)
    fig.tight_layout();save("fig4b_weight_tradeoff")

def fig5():
    u=pd.read_csv(D/"uncertainty_decomposition.csv")
    n=pd.read_csv(D/"nonlinear_set_results.csv")
    pn=pd.read_csv(D/"partial_nonlinear_set.csv")
    fig,ax=plt.subplots(1,3,figsize=(10,2.9))
    q=u[(u.regime=="informative")&(u.vehicle_index==20)]
    cols=["inherited_screen_m","local_road_points_screen_m",
          "station_correspondence_screen_m","timestamp_age_screen_m",
          "reference_point_geometry_screen_m"]
    labels=["inherited","local points","station","age","geometry"]
    vals=q[cols].mean().values
    ax[0].barh(labels,vals,color="#337f91")
    ax[0].set(xscale="log",xlabel="End-path contribution (m)",
              title="Old N=20 screen decomposition")
    m=n.groupby("W_m")[["old_linear_path_screen_m",
                        "nonlinear_union_path_screen_m",
                        "actual_end_error_m"]].mean()
    xx=np.arange(len(m));ww=.24
    ax[1].bar(xx-ww,m.old_linear_path_screen_m,ww,label="old linear")
    ax[1].bar(xx,m.nonlinear_union_path_screen_m,ww,label="nonlinear union")
    ax[1].bar(xx+ww,m.actual_end_error_m,ww,label="actual")
    ax[1].set(xticks=xx,xticklabels=[f"W={z:g} m" for z in m.index],
              yscale="log",ylabel="End-path distance (m)",
              title="Same low-order shape contract")
    ax[1].legend(fontsize=7)
    q=pn.groupby("visible_m")[["nonlinear_union_far_screen_m",
                               "actual_far_error_m"]].mean()
    ax[2].plot(q.index,q.nonlinear_union_far_screen_m,"o-",label="outer screen")
    ax[2].plot(q.index,q.actual_far_error_m,"s--",label="actual")
    ax[2].axhline(1,color="black",ls=":",lw=.8)
    ax[2].set(xlabel="Local visible distance (m)",
              ylabel="30 m far-path distance (m)",
              title="Partial visibility extrapolation")
    ax[2].legend(fontsize=7)
    fig.tight_layout();save("fig5_uncertainty")

def fig6():
    x=pd.read_csv(D/"partial_visibility_results.csv")
    chosen={8.:100.,12.:10.,15.:1.,30.:.001}
    q=x[(x.vehicle_index==20)&(x.apply(
        lambda r: abs(r.p-chosen[r.visible_m])<1e-12,axis=1))]
    g=q.groupby(["visible_m","method"])[["valid_preview_m",
                                          "error_at_valid_preview_m"]].mean()
    fig,ax=plt.subplots(1,2,figsize=(8.5,2.8))
    methods=["local_only","v2v_only","fused"]
    colors=["#d08b2d","#ad4a5c","#2b8290"]
    for j,method in enumerate(methods):
        sub=g.xs(method,level="method")
        ax[0].plot(sub.index,sub.valid_preview_m,"o-",color=colors[j],
                   label=method.replace("_"," "))
        ax[1].plot(sub.index,sub.error_at_valid_preview_m,"o-",
                   color=colors[j],label=method.replace("_"," "))
    ax[0].axhline(30,color="black",ls=":",lw=.8)
    ax[0].set(xlabel="Local visible distance (m)",ylabel="Valid preview (m)",
              title="Synthetic path availability")
    ax[1].set(xlabel="Local visible distance (m)",
              ylabel="N=20 path error at valid preview (m)",
              title="Comparison uses each method's valid horizon")
    ax[1].set_yscale("log")
    ax[1].legend(fontsize=7)
    fig.tight_layout();save("fig6_partial_visibility")

def fig7():
    x=pd.read_csv(D/"matlab_dynamic_results.csv")
    f=x[x.method=="fused"].copy()
    f["label"]=f.scenario.str.replace("D1_curve_occlusion","D1",regex=False)\
        .str.replace("D2_s_curve","D2",regex=False)\
        .str.replace("D3_v2v_burst","D3",regex=False)\
        .str.replace("D4_heterogeneous","D4",regex=False)\
        .str.replace("D5_low_friction","D5",regex=False)+" N"+f.N.astype(str)
    fig,ax=plt.subplots(1,2,figsize=(9.5,3))
    labels=list(dict.fromkeys(f.label))
    xx=np.arange(len(labels))
    for aware,shift,color,name in [(0,-.18,"#ad4a5c","nominal"),
                                   (1,.18,"#2b8290","uncertainty-aware heuristic")]:
        z=f[f.uncertainty_aware==aware].set_index("label").loc[labels]
        fractions=z.corridor_violation_fraction.to_numpy().copy()
        fractions[z.validity_terminated.astype(bool).to_numpy()]=np.nan
        ax[0].bar(xx+shift,fractions,.36,color=color,label=name)
        ax[1].bar(xx+shift,z.mean_valid_preview_m,.36,color=color,label=name)
    if "D5 N5" in labels:
        ax[0].text(labels.index("D5 N5")-.18,.05,"nominal\nterminated",
                   rotation=90,ha="center",va="bottom",fontsize=6)
    ax[0].set(xticks=xx,xticklabels=labels,
              ylabel="Body-corridor violation fraction",
              title="MATLAB nonlinear bicycle diagnostics")
    ax[1].set(xticks=xx,xticklabels=labels,
              ylabel="Mean valid preview (m)",title="Causal sensor/V2V path fits")
    for a in ax:
        plt.setp(a.get_xticklabels(),rotation=30,ha="right")
    ax[0].legend(fontsize=7)
    fig.tight_layout();save("fig7_matlab_dynamics")

if __name__=="__main__":
    fig3();fig4();fig4b();fig5();fig6();fig7()
