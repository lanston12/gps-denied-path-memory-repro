"""Publication figures from stored v3 CSVs; no hard-coded outcome values."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reference_estimator import fit_model, select_model, path_points
from adaptive_models import composite_road
from path_model import rot

ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'data';F=ROOT/'figures'
plt.rcParams.update({'font.size':8,'axes.titlesize':9,'pdf.fonttype':42,
                     'figure.dpi':180,'savefig.bbox':'tight'})
COL={'local_only':'#9c6b31','v2v_only':'#b55b4e','pose_v2v':'#8a78a6',
     'fused':'#197f8f','nominal_fusion':'#b55b4e','admissible_fusion':'#197f8f'}

def save(fig,name):
    fig.savefig(F/(name+'.pdf'));fig.savefig(F/(name+'.png'))
    plt.close(fig)

def model_gate():
    info=[]
    for vis in (8.,12.,15.,30.):
        s=np.linspace(0,vis,16)
        pts=np.column_stack([s,path_points(s,30.,'M2',[.005,.002])])
        for m in ('M1','M2','M3','M4'):
            q=fit_model(pts,30.,m)
            info.append(dict(visible_m=vis,model=m,mu=q['mu']))
    pd.DataFrame(info).to_csv(D/'v3_model_information.csv',index=False)
    ss,x,y,psi=composite_road();selection=[]
    for start in (0,8,12,20,28,35,42,49):
        s=np.linspace(0,30,16);global_s=start+s
        xy=np.column_stack([np.interp(global_s,ss,x),np.interp(global_s,ss,y)])
        origin=np.array([np.interp(start,ss,x),np.interp(start,ss,y)])
        local=(xy-origin)@rot(-np.interp(start,ss,psi)).T
        selected,allfit=select_model(local)
        selection.append(dict(start_m=start,selected=selected['model'] if selected else 'none',
                              min_residual_m=min(q['max_residual'] for q in allfit)))
    pd.DataFrame(selection).to_csv(D/'v3_model_gate.csv',index=False)
    fig,ax=plt.subplots(1,2,figsize=(7.2,2.6),layout='constrained')
    tab=pd.DataFrame(info)
    for m,g in tab.groupby('model'):
        ax[0].plot(g.visible_m,np.maximum(g.mu,1e-3),'o-',label=m)
    ax[0].axhline(1,color='k',ls='--',lw=.8)
    ax[0].set_yscale('log');ax[0].set_xlabel('Local visibility (m)')
    ax[0].set_ylabel('Physical information eigenvalue');ax[0].legend(ncol=2,fontsize=7)
    sel=pd.DataFrame(selection);codes={'none':0,'M1':1,'M2':2,'M3':3,'M4':4}
    ax[1].step(sel.start_m,[codes[z] for z in sel.selected],where='mid',marker='o')
    ax[1].set_yticks(range(5),list(codes));ax[1].set_xlabel('Composite-road start (m)')
    ax[1].set_ylabel('Accepted model')
    save(fig,'fig3_model_gate_v3')

def gain_fig():
    d=pd.read_csv(D/'admissible_preview_results.csv')
    q=d[(d.N==20)&(d.epsilon_ref_m==.2)&(d.method=='fused')]
    p=pd.read_csv(D/'admissible_all_interval_products.csv')
    p=p[(p.N==20)&(p.epsilon_ref_m==.2)].copy();p['span']=p.end-p.start+1
    a=pd.read_csv(D/'cross_model_transport_audit.csv')
    fig,ax=plt.subplots(1,3,figsize=(10,2.6),layout='constrained')
    g=q.groupby('visible_m').physical_gain.max()
    ax[0].plot(g.index,g.values,'o-',color=COL['fused'])
    ax[0].axhline(1,color='k',ls='--',lw=.8)
    ax[0].set_xlabel('Local visibility (m)');ax[0].set_ylabel('Maximum hop gain')
    for vis in (8.,15.,30.):
        z=p[p.visible_m==vis].groupby('span')['product'].max()
        ax[1].plot(z.index,z.values,label=f'{vis} m')
    ax[1].set_yscale('log');ax[1].set_xlabel('Contiguous span (hops)')
    ax[1].set_ylabel('Maximum product');ax[1].legend(fontsize=7)
    z=a.groupby('p').basis_invariance_error.max()
    ax[2].bar(z.index.astype(str),z.values,color='#596a89')
    ax[2].set_xlabel('Matrix-prior weight');ax[2].set_ylabel('Max rescaling difference')
    ax[2].ticklabel_format(axis='y',style='sci',scilimits=(0,0))
    save(fig,'fig4_physical_gain_v3')

def transport_fig():
    d=pd.read_csv(D/'cross_model_transport_audit.csv');q=d[(d.p==1)&(d.sequence=='realized')]
    pairs=d[(d.p==1)&(d.sequence=='pair_test')]
    m=('M1','M2','M3','M4')
    heat=np.array([[pairs[(pairs.source==a)&(pairs.destination==b)]
                    .projection_lateral_max_m.iloc[0] for b in m] for a in m])
    fig,ax=plt.subplots(1,2,figsize=(8.5,2.8),layout='constrained')
    ax[0].plot(q.hop,q.chain_gain,'o-',label='gain incl. norm connector')
    ax[0].plot(q.hop,q.physical_gain,'--',color='#56677a',lw=.8,label='single hop')
    ax[0].axhline(1,color='k',ls=':',lw=.8)
    ax[0].set_xlabel('Realized model switch');ax[0].set_ylabel('Physical gain')
    ax[0].legend(fontsize=6,loc='upper left')
    a2=ax[0].twinx();a2.bar(q.hop,q.projection_lateral_max_m,alpha=.3,
                            color='#c26e37',label='projection residual')
    a2.set_ylabel('Projection lateral residual (m)')
    im=ax[1].imshow(heat,cmap='YlOrRd',origin='lower',aspect='auto')
    ax[1].set_xticks(range(4),m);ax[1].set_yticks(range(4),m)
    ax[1].set_xlabel('Destination basis');ax[1].set_ylabel('Source basis')
    fig.colorbar(im,ax=ax[1],label='Max lateral residual (m)')
    save(fig,'fig5_cross_model_v3')

def preview_fig():
    d=pd.read_csv(D/'admissible_preview_results.csv')
    q=d[(d.N==20)&(d.vehicle_index==20)&(d.epsilon_ref_m==.2)]
    fig,ax=plt.subplots(1,3,figsize=(10,2.7),layout='constrained')
    for m in ('local_only','v2v_only','pose_v2v','fused'):
        g=q[q.method==m].groupby('visible_m').mean(numeric_only=True)
        ax[0].plot(g.index,g.nominal_preview_m,'o--',color=COL[m],alpha=.45)
        ax[0].plot(g.index,g.admissible_preview_m,'o-',color=COL[m],label=m.replace('_',' '))
        ax[1].plot(g.index,g.far_30m_error_m,'o-',color=COL[m],label=m.replace('_',' '))
    ax[0].set_xlabel('Local visibility (m)');ax[0].set_ylabel('Preview (m)')
    ax[0].legend(fontsize=6,ncol=2)
    ax[0].set_title('Dashed: nominal; solid: admissible')
    ax[1].set_xlabel('Local visibility (m)');ax[1].set_ylabel('30-m error when supported (m)')
    z=d[(d.N==20)&(d.vehicle_index==20)&(d.method=='fused')]
    for eps,g in z.groupby('epsilon_ref_m'):
        h=g.groupby('visible_m').admissible_preview_m.mean()
        ax[2].plot(h.index,h.values,'o-',label=f'{eps:.1f} m')
    ax[2].set_xlabel('Local visibility (m)');ax[2].set_ylabel('Fused admissible preview (m)')
    ax[2].legend(title='Quality threshold',fontsize=7,title_fontsize=7)
    save(fig,'fig6_admissible_preview_v3')

def dynamics_fig():
    d=pd.read_csv(D/'integrated_dynamic_results.csv')
    d=d[(d.N.isin([5,10,20]))&~((d.scenario=='D1_curve_occlusion')&(d.N!=20))]
    names={'D1_curve_occlusion':'D1, N20','D2_s_curve':'D2, N10',
           'D3_v2v_burst':'D3, N10','D4_heterogeneous':'D4, N20'}
    scenarios=list(names);methods=('local_only','nominal_fusion','admissible_fusion')
    fig,ax=plt.subplots(1,3,figsize=(10,2.8),layout='constrained')
    x=np.arange(len(scenarios));width=.25
    metrics=('mean_valid_preview_m','lateral_rmse_m','corridor_violation_fraction')
    labels=('Controller preview (m)','Lateral RMSE (m)','Body corridor violation fraction')
    for j,(metric,label) in enumerate(zip(metrics,labels)):
        for k,m in enumerate(methods):
            v=[d[(d.scenario==s)&(d.method==m)][metric].iloc[0] for s in scenarios]
            ax[j].bar(x+(k-1)*width,v,width,label=m.replace('_',' '),color=COL[m])
        ax[j].set_xticks(x,[names[s] for s in scenarios],rotation=35,ha='right')
        ax[j].set_ylabel(label)
    ax[0].legend(fontsize=6)
    save(fig,'fig7_integrated_matlab_v3')

if __name__=='__main__':
    F.mkdir(exist_ok=True)
    model_gate();gain_fig();transport_fig();preview_fig();dynamics_fig()
