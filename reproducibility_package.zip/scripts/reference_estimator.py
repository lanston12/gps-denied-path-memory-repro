"""Finite-basis physical path interface shared with matlab/estimate_reference.m.

The linearized normal-graph map is valid only while its residual gate passes.
Quality radii are engineering pointwise indices, not calibrated coverage bands.
"""
import numpy as np

MODELS = ("M1", "M2", "M3", "M4")
DIM = {"M1": 1, "M2": 2, "M3": 3, "M4": 4}
SCALES = np.array([.2, .02, .002])


def fields(s, W, model):
    s = np.asarray(s, dtype=float).reshape(-1)
    u = s / W
    if model == "M1":
        k = np.stack([np.ones_like(u)], axis=1)
        psi = np.stack([s], axis=1)
        y = np.stack([s**2 / 2], axis=1)
    elif model == "M2":
        k = np.stack([np.ones_like(u), u], axis=1)
        psi = np.stack([s, s**2 / (2*W)], axis=1)
        y = np.stack([s**2/2, s**3/(6*W)], axis=1)
    elif model == "M3":
        z = np.maximum(s-W/2, 0)
        k = np.stack([np.ones_like(u), u, np.maximum(u-.5, 0)], axis=1)
        psi = np.stack([s, s**2/(2*W), z**2/(2*W)], axis=1)
        y = np.stack([s**2/2, s**3/(6*W), z**3/(6*W)], axis=1)
    elif model == "M4":
        polys = np.array([[1,-3,3,-1], [0,3,-6,3],
                          [0,0,3,-3], [0,0,0,1]], dtype=float)
        k = np.column_stack([sum(polys[j,n]*u**n for n in range(4)) for j in range(4)])
        psi = np.column_stack([sum(polys[j,n]*s**(n+1)/((n+1)*W**n)
                                   for n in range(4)) for j in range(4)])
        y = np.column_stack([sum(polys[j,n]*s**(n+2)/((n+1)*(n+2)*W**n)
                                 for n in range(4)) for j in range(4)])
    else:
        raise ValueError(model)
    return y, psi, k


def path_points(s, W, model, coeff, offset=0., heading=0.):
    s = np.asarray(s, dtype=float).reshape(-1)
    y, _, _ = fields(s, W, model)
    return offset + heading*s + y @ np.asarray(coeff)


def physical_matrix(s, W, model):
    y, psi, k = fields(s, W, model)
    return np.concatenate([y/SCALES[0], psi/SCALES[1], k/SCALES[2]], axis=0)


def physical_Q(W, model, support=None):
    support = W if support is None else support
    s = np.linspace(0, support, 121)
    y, psi, k = fields(s, W, model)
    Z = np.stack([y/SCALES[0], psi/SCALES[1], k/SCALES[2]], axis=1)
    return np.trapezoid(np.einsum('nac,nad->ncd', Z, Z), s, axis=0)/support


def induced(B, Qout, Qin):
    co = np.linalg.cholesky(Qout).T
    ci = np.linalg.cholesky(Qin).T
    return float(np.linalg.svd(co @ B @ np.linalg.inv(ci), compute_uv=False)[0])


def cross_model(source, destination, shift, Wsrc=30., Wdst=30., support=None):
    support = min(Wdst, Wsrc-shift) if support is None else support
    if support <= 0 or shift < 0 or support+shift > Wsrc+1e-10:
        raise ValueError('station outside source support')
    s = np.linspace(0, support, 121)
    ys, ps, ks = fields(s+shift, Wsrc, source)
    y0, p0, _ = fields([shift], Wsrc, source)
    Ea = np.concatenate([(ys-y0-s[:,None]*p0)/SCALES[0],
                         (ps-p0)/SCALES[1], ks/SCALES[2]], axis=0)
    Eb = physical_matrix(s, Wdst, destination)
    # The online Python/MATLAB estimator projects sampled physical road
    # points, while fitting translation and tangent as nuisance variables.
    # Audit that actual point-collocation map in the full physical Q metric.
    yb = fields(s, Wdst, destination)[0]
    G = np.column_stack([np.ones_like(s), s])
    ya_reduced = (ys-y0-s[:,None]*p0)-G@np.linalg.lstsq(G,ys-y0-s[:,None]*p0,rcond=None)[0]
    yb_reduced = yb-G@np.linalg.lstsq(G,yb,rcond=None)[0]
    T = np.linalg.lstsq(yb_reduced, ya_reduced, rcond=None)[0]
    Qsrc = Ea.T@Ea/len(s)
    Qdst = Eb.T@Eb/len(s)
    residual = Ea-Eb@T
    return T, Qsrc, Qdst, residual, support


def local_information(x, W, model, sigma=.01):
    x = np.asarray(x, dtype=float).reshape(-1)
    H = fields(x, W, model)[0]
    G = np.column_stack([np.ones_like(x), x])
    Hs = H-G@np.linalg.lstsq(G, H, rcond=None)[0]
    return Hs.T@Hs/sigma**2


def fit_model(points, W, model, sigma=.01):
    pts = np.asarray(points, dtype=float)
    x, obs = pts[:,0], pts[:,1]
    H = fields(x, W, model)[0]
    design = np.column_stack([np.ones_like(x), x, H])
    q = np.linalg.lstsq(design, obs, rcond=None)[0]
    residual = obs-design@q
    J = local_information(x, W, model, sigma)
    Q = physical_Q(W, model, max(x))
    eig = np.linalg.eigvalsh(Q)
    if eig[0] <= 1e-12*eig[-1]:
        # This model's extra mode is physically unsupported on this window.
        mu = 0.
    else:
        c = np.linalg.cholesky(Q).T
        ci = np.linalg.inv(c)
        mu = float(max(0, np.linalg.eigvalsh(ci.T@J@ci)[0]))
    return dict(model=model, W=W, offset=q[0], heading=q[1],
                coeff=q[2:], max_residual=float(np.max(np.abs(residual))),
                rms_residual=float(np.sqrt(np.mean(residual**2))),
                J=J, Q=Q, mu=mu, support=float(max(x)))


def select_model(points, W=30., sigma=.01, residual_gate=.03, info_gate=1.):
    # Physical information and fit must both pass. Shorter visible support
    # remains the only accepted support unless a valid remote message extends it.
    candidates = [fit_model(points, W, m, sigma) for m in MODELS]
    valid = [f for f in candidates if f['mu'] >= info_gate and
             f['max_residual'] <= residual_gate]
    return (valid[0] if valid else None), candidates


def quality_radius(fit, s, sigma=.01, projection_rms=0., age=0.):
    if fit is None or s > fit['support']+1e-9:
        return np.inf
    h = fields([s], fit['W'], fit['model'])[0][0]
    cov = np.linalg.inv(fit['J'])
    # Gaussian-style variance scaling plus empirical fit, projection and age
    # allowances. The complete index has no calibrated coverage interpretation.
    return float(1.96*np.sqrt(max(0, h@cov@h)) +
                 2*fit['max_residual'] + projection_rms + .02*age)


def admissible_length(fit, epsilon, age=0., age_max=.8, projection_rms=0., step=.5):
    if fit is None or age > age_max:
        return 0.
    grid = np.arange(0, fit['support']+step/2, step)
    good = 0.
    for s in grid:
        if quality_radius(fit, s, projection_rms=projection_rms, age=age) > epsilon:
            break
        good = s
    return float(good)


def estimate_reference(local_points, remote_points=None, age=0., mode='admissible_fusion',
                       epsilon=.2):
    """Causal common-interface update matched by MATLAB estimate_reference.m."""
    local_points = np.asarray(local_points, float)
    selected, candidates = select_model(local_points)
    model_valid = selected is not None
    selected = dict(selected if model_valid else candidates[0])
    remote_points = None if remote_points is None else np.asarray(remote_points, float)
    have_remote = (remote_points is not None and len(remote_points)>0 and age<=.8
                   and mode!='local_only')
    nominal = min(30., float(np.max(local_points[:,0])))
    projection_rms = 0.
    if have_remote:
        nominal = min(30., max(nominal, float(np.max(remote_points[:,0]))))
        destination = fit_model(remote_points, 30., selected['model'])
        projection_rms = destination['rms_residual']
        if mode == 'v2v_only':
            selected = dict(destination)
        else:
            Q = physical_Q(30., selected['model'], float(np.max(local_points[:,0])))
            A = np.linalg.solve(np.eye(len(selected['coeff']))+
                                np.linalg.solve(Q, selected['J']),
                                np.eye(len(selected['coeff'])))
            selected['coeff'] = (A@destination['coeff'] +
                                 (np.eye(len(selected['coeff']))-A)@selected['coeff'])
    selected['support'] = nominal
    quality_preview = (admissible_length(selected, epsilon, age=age if have_remote else 0.,
                                         projection_rms=projection_rms)
                       if model_valid else 0.)
    usable = quality_preview if mode == 'admissible_fusion' else nominal
    if not have_remote:
        usable = min(usable, float(np.max(local_points[:,0])))
    if not model_valid and mode == 'admissible_fusion':
        usable = 0.
    selected.update(model_valid=model_valid, age_valid=have_remote,
                    nominal=nominal, admissible=usable, quality_preview=quality_preview,
                    projection_rms=projection_rms,
                    remote_shortened=bool(have_remote and quality_preview+1e-9<nominal))
    return selected
