"""Five-hop 2-D convex outer-set transport and local road-point intersection."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial import ConvexHull
from path_model import curve_and_shape_jac,fit_road_shape,rot,station_map
from nonlinear_set import outer_boxes

D=Path(__file__).resolve().parents[1]/"data"
W=30.

def hull(points):
    p=np.unique(np.asarray(points,float),axis=0)
    if len(p)<=2:return p
    return p[ConvexHull(p).vertices]

def boxes_hull(boxes):
    corners=[]
    for a,b,c,d in boxes:
        corners.extend([[a,c],[a,d],[b,c],[b,d]])
    return hull(corners)

def inside(p,a,b):
    return np.cross(b-a,p-a)>=-1e-12

def clip(subject,clipper):
    out=np.asarray(subject,float)
    for a,b in zip(clipper,np.roll(clipper,-1,axis=0)):
        if not len(out):break
        inp=out;out=[]
        for u,v in zip(inp,np.roll(inp,-1,axis=0)):
            ui=inside(u,a,b);vi=inside(v,a,b)
            if ui and vi:out.append(v)
            elif ui!=vi:
                edge=v-u; line=b-a
                den=np.cross(edge,line)
                if abs(den)>1e-18:
                    t=np.cross(a-u,line)/den
                    x=u+t*edge
                    out.append(x)
                if vi:out.append(v)
        out=np.asarray(out,float).reshape(-1,2)
    return hull(out) if len(out)>=3 else out

def path_end_screen(poly,center):
    _,jac=curve_and_shape_jac(np.array([W]),center,W)
    J=jac[0]
    E=poly-center
    linear=max(np.linalg.norm(E@J.T,axis=1))
    Hmax=23*W**3/60
    remainder=.5*Hmax*max(np.sum(E*E,axis=1))
    return float(linear+remainder)

def run():
    rng=np.random.default_rng(12091)
    g0=.005;g1=.0015
    initial=np.array([g0,g1])
    prior=None
    rows=[]
    for i in range(6):
        true=np.array([g0+g1*i*2.5/W,g1])
        visible=30. if i==0 else 15.
        s=np.linspace(0,visible,16)
        p,_=curve_and_shape_jac(s,true,W)
        theta=rng.uniform(-np.pi,np.pi)
        obs=p@rot(theta).T+rng.uniform(-5,5,2)+rng.uniform(-.01,.01,p.shape)
        fit=fit_road_shape(s,obs,W,.01)
        local=outer_boxes(s,obs,W,.01,max_evals=12000,width_target=2e-4)
        local_poly=boxes_hull(local["box_list"])
        local_screen=path_end_screen(local_poly,fit["coeff"])
        if i==0:
            fused=local_poly
            v2v_screen=np.nan
        else:
            F=station_map(2.5/W)
            mapped=prior@F.T
            # Declared station/correspondence ±0.08 m and rigid geometry
            # coefficient perturbation. Inflated box is a conservative
            # coefficient-set outer approximation for each hop.
            d0=.08/W*.01 + (.02**2)*.1
            d1=.02*.005*.1
            offsets=np.array([[a,b] for a in [-d0,d0] for b in [-d1,d1]])
            v2v=hull((mapped[:,None,:]+offsets[None,:,:]).reshape(-1,2))
            v2v_screen=path_end_screen(v2v,fit["coeff"])
            fused=clip(v2v,local_poly)
            if len(fused)<3:
                # Empty intersection is a required invalidity signal.
                rows.append({"index":i,"status":"empty_intersection"})
                break
        fused_screen=path_end_screen(fused,fit["coeff"])
        truthinside=all(inside(true,a,b)
                        for a,b in zip(fused,np.roll(fused,-1,axis=0)))
        rows.append({"index":i,"status":"valid" if truthinside else "truth_excluded",
                     "visible_m":visible,"desired_preview_m":W,
                     "local_only_far_screen_m":local_screen,
                     "v2v_only_far_screen_m":v2v_screen,
                     "fused_far_screen_m":fused_screen,
                     "local_set_status":local["status"],
                     "local_set_evals":local["evaluations"],
                     "local_polygon_vertices":len(local_poly),
                     "fused_polygon_vertices":len(fused)})
        prior=fused
        print("hop",i,"screen",fused_screen,"status",rows[-1]["status"],flush=True)
    out=pd.DataFrame(rows)
    out.to_csv(D/"set_fusion_results.csv",index=False)
    return out
if __name__=="__main__":
    run()
