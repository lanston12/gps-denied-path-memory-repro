"""Descriptive seed summaries under the fixed synthetic contracts."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t
P=Path(__file__).resolve().parents[1]
rows=[]
def add(study,condition,method,metric,values):
 a=np.asarray(pd.Series(values).dropna(),float);n=len(a)
 if not n:return
 mean=float(a.mean());sd=float(a.std(ddof=1)) if n>1 else 0.
 half=float(t.ppf(.975,n-1)*sd/np.sqrt(n)) if n>1 else 0.
 rows.append(dict(study=study,condition=condition,method=method,metric=metric,n=n,mean=mean,q25=float(np.quantile(a,.25)),q75=float(np.quantile(a,.75)),ci95_low=mean-half,ci95_high=mean+half))
x=pd.read_csv(P/'data/tvt_primary30_preview_results.csv');x=x[x.vehicle_index==20]
for method,z in x.groupby('method'):
 for metric in ('nominal_preview_m','admissible_preview_m','far_30m_error_m'):
  add('estimator','N20_vis15_eps0.2',method,metric,z[metric])
a=x.pivot(index='seed',columns='method',values='admissible_preview_m')
add('estimator','N20_vis15_eps0.2','fused-minus-local','admissible_preview_m',a.fused-a.local_only)
y=pd.read_csv(P/'data/tvt_D3_D4_paired_results.csv')
for scenario,z in y.groupby('scenario'):
 for metric in ('mean_valid_preview_m','lateral_rmse_m','corridor_violation_fraction'):
  a=z.pivot(index='seed',columns='method',values=metric)
  for method in a.columns:add('MATLAB',scenario,method,metric,a[method])
  add('MATLAB',scenario,'admitted-minus-nominal',metric,a.admissible_fusion-a.nominal_fusion)
  add('MATLAB',scenario,'admitted-minus-local',metric,a.admissible_fusion-a.local_only)
pd.DataFrame(rows).to_csv(P/'data/tvt_seed_summary.csv',index=False)
print('Wrote',len(rows),'generator-conditional descriptive summary rows')
