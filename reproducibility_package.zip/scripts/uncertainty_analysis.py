"""Trace the conservative screen into physically named additive sources."""
from pathlib import Path
import numpy as np
import pandas as pd
from path_model import station_map

D=Path(__file__).resolve().parents[1]/"data"
h=pd.read_csv(D/"hop_parameters.csv")
s=pd.read_csv(D/"scaling_results.csv")
P_SCALAR_V1=1e-6

def run():
    rows=[]
    for (regime,N,seed),g in h[h.N==20].groupby(["regime","N","seed"]):
        g=g.sort_values("vehicle_index")
        W=float(g.iloc[0].window_m)
        components={"inherited":.00022,"local_road_points":0.,
                    "station_correspondence":0.,"timestamp_age":0.,
                    "reference_point_geometry":0.,"basis_mismatch":0.}
        for r in g.itertuples():
            x=np.array([r.true_k0_1pm,r.true_k1_1pm])
            J=np.array([[r.J_00,r.J_01],[r.J_01,r.J_11]])
            A=np.linalg.inv(np.eye(2)+P_SCALAR_V1*J)
            F=station_map((2.5+r.station_error_m)/W)
            gain=np.linalg.norm(A@F,2)
            for key in components: components[key]*=gain
            comp={"local_road_points":np.linalg.norm(np.eye(2)-A,2)*r.local_bound_screen_1pm,
                  "station_correspondence":np.linalg.norm(A@np.array([1.,0.]))*
                  abs(x[1])*.04/W,
                  "timestamp_age":np.linalg.norm(A@np.array([1.,0.]))*
                  abs(x[1])*.10*r.age_s/W,
                  "reference_point_geometry":np.linalg.norm(A,2)*
                  max(abs(x[0]),abs(x[0]+x[1]))**2*.1*np.sqrt(2),
                  "basis_mismatch":0.}
            for key,val in comp.items():components[key]+=val
            factor=np.hypot(W*W/2,W*W/6)
            row={"regime":regime,"N":N,"seed":seed,"vehicle_index":r.vehicle_index,
                 "total_screen_m":sum(components.values())*factor}
            row.update({key+"_screen_m":value*factor
                        for key,value in components.items()})
            rows.append(row)
    out=pd.DataFrame(rows)
    out=out.merge(s[["regime","N","seed","vehicle_index","path_end_error_m"]],
                  on=["regime","N","seed","vehicle_index"],how="left")
    out.to_csv(D/"uncertainty_decomposition.csv",index=False)
    end=out[out.vehicle_index==20]
    print(end.groupby("regime").mean(numeric_only=True)[[
        "inherited_screen_m","local_road_points_screen_m",
        "station_correspondence_screen_m","timestamp_age_screen_m",
        "reference_point_geometry_screen_m","total_screen_m"]].to_string())
    return out
if __name__=="__main__":
    run()
