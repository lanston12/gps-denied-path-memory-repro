"""Verify the integrated document, printed primitive formulas and final layout.

No simulation is executed. Scientific records are checked against frozen files.
"""
from pathlib import Path
import hashlib,json,re,subprocess
import fitz
import numpy as np
from scipy.integrate import quad
from reference_estimator import fields

R=Path(__file__).resolve().parents[1]
main=(R/'main.tex').read_text(encoding='utf-8')
source_record=json.loads((R/'data/integration_source_manifest.json').read_text())
source=Path(source_record['source_directory'])
frozen=(source/'main.tex').read_text(encoding='utf-8')
assert not (R/'supplement.pdf').exists() and not (R/'supplement.tex').exists()
sections=re.findall(r'\\section\{([^}]+)\}',main)
assert sections[:6]==[
    'Introduction','Related Work and Problem Formulation',
    'Model-Gated Reference-Information Framework','Validation Methodology',
    'Results and Discussion','Conclusion']
assert len(sections)==8 and len(re.findall(r'\\begin\{figure\*?\}',main))==7
assert len(re.findall(r'\\begin\{table\*?\}',main))==2
assert r'\label{tab:keyresults}' not in main and r'\section{Discussion}' not in main
for tag in ('app:basis','app:transport','eq:preview','eq:quality',
            'eq:bases','eq:polyprimitive','eq:bernsteinpsi','eq:bernsteinh',
            'eq:fourhop','eq:unrolled','eq:injections','eq:fullresidual'):
    assert '\\label{'+tag+'}' in main,tag
assert 'Followers are indexed by $i=1,\\ldots,N$' in main
assert r'|\theta_i|\ll1' in main and r'|\psi|\ll1' not in main
assert r'\widetilde G_{j:i}=c_jG_{j:i}' in main
assert r'G_{j:j+2}=\gamma_j^{\rm phys}c_{j+1}' in main
assert 'information threshold four' in main and '0.01 m' in main
assert (R/'references.bib').read_bytes()==(source/'references.bib').read_bytes()
abstract=main.split(r'\begin{abstract}')[1].split(r'\end{abstract}')[0]
assert 180<=len(abstract.split())<=210 and '30 paired' in abstract and '23.02' in abstract

def acknowledgment(s):
    start=s.index(r'\section*{Acknowledgment}')
    return s[start:s.index(r'\end{minipage}',start)].strip()
assert acknowledgment(main)==acknowledgment(frozen)
without_ack=main.replace(acknowledgment(main),'')
assert not re.search(r'\b(?:supplement|supplementary)\b',without_ack,re.I)
assert 'CarSim' not in main

# Parse the actual printed Bernstein matrices, rather than a duplicate test copy.
def matrix_after(start):
    t=main[main.index(start):]
    t=t[t.index(r'\begin{bmatrix}')+len(r'\begin{bmatrix}'):]
    return t[:t.index(r'\end{bmatrix}')].strip().split(r'\\')

frac=re.compile(r'\\tfrac(?:\{(\d+)\}|(\d))(?:\{(\d+)\}|(\d))')
def polynomial(row,u):
    row=frac.sub(lambda m:'('+str(m[1] or m[2])+'/'+str(m[3] or m[4])+')',row)
    row=re.sub(r'u\^(\d+)',r'u**\1',row)
    row=re.sub(r'(\)|\d)u',r'\1*u',row)
    assert re.fullmatch(r'[\du\s()+*/.\-]+',row),row
    return eval(row,{'__builtins__':{}},{'u':u})

psi_rows=matrix_after(r'\frac{\Psi_{\rm M4,W}(s)^\top}{W}')
h_rows=matrix_after(r'\frac{H_{\rm M4,W}(s)^\top}{W^2}')
assert len(psi_rows)==len(h_rows)==4
coeff_rows=matrix_after('[a_{jn}]')
coeff=np.array([[float(z) for z in row.split('&')] for row in coeff_rows])
assert coeff.shape==(4,4)
max_printed_error=0.
for W in (8.,15.,30.):
    for u in (0.,.1,.3,.5,.8,1.):
        s=W*u
        h,p,k=fields([s],W,'M4')
        assert np.allclose(coeff@np.array([1.,u,u*u,u**3]),k[0],atol=1e-12)
        pp=np.array([polynomial(row,u)*W for row in psi_rows])
        hh=np.array([polynomial(row,u)*W*W for row in h_rows])
        max_printed_error=max(max_printed_error,float(np.max(np.abs(pp-p[0]))),
                              float(np.max(np.abs(hh-h[0]))))
        for j in range(4):
            basis=lambda v:float(coeff[j]@np.array([1.,v/W,(v/W)**2,(v/W)**3]))
            assert np.isclose(pp[j],quad(basis,0,s)[0],atol=1e-10)
            assert np.isclose(hh[j],quad(lambda v:(s-v)*basis(v),0,s)[0],atol=1e-10)
assert max_printed_error<1e-10

# Every earlier source file is immutable; scientific records and figure assets match.
scientific=0;assets=0
migrated={'scripts/verify_v3.py','scripts/verify_tvt.py','scripts/verify_final_audit.py'}
for item in source_record['files']:
    rel=item['path'];digest=item['sha256']
    assert hashlib.sha256((source/rel).read_bytes()).hexdigest()==digest,rel
    if rel.startswith('figures/'):
        assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==digest,rel
        assets+=1
    if rel.endswith(('.csv','.m')) or (rel.startswith('scripts/') and rel.endswith('.py')):
        p=(R/'reproducibility/legacy_verification'/Path(rel).name) if rel in migrated else R/rel
        assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,rel
        scientific+=1

doc=fitz.open(R/'main.pdf')
assert len(doc)<=14
positions={}
page_rects=[]
for i,page in enumerate(doc):
    valid=[]
    for block in page.get_text('dict')['blocks']:
        if block.get('type')==1:
            valid.append(block['bbox']);continue
        for line in block.get('lines',[]):
            t=''.join(span['text'] for span in line['spans']).strip()
            if re.fullmatch(r'\d+',t) and line['bbox'][1]<40:continue
            valid.append(line['bbox'])
            if t in ('TABLE I','TABLE II','VI. CONCLUSION','APPENDIX A','APPENDIX B',
                     'ACKNOWLEDGMENT','REFERENCES','DATA AND CODE AVAILABILITY'):
                positions[t]={'page':i+1,'bbox':line['bbox']}
            if any(t.startswith(f'Fig. {n}.') for n in range(1,8)) and line['spans'][0]['size']<8.2:
                n=re.match(r'Fig\. (\d+)\.',t)[1]
                positions['Fig. '+n+'.']={'page':i+1,'bbox':line['bbox']}
    assert valid
    for box in valid:
        assert box[0]>=35 and box[2]<=577 and box[1]>=45 and box[3]<=755,(i+1,box)
    bottom=max(box[3] for box in valid)
    # A partial final bibliography page is natural; main/appendix pages must be occupied.
    bibliography_tail=(i==len(doc)-1 and bool(re.search(r'\[\d+\]',page.get_text()))
                       and not any(x in page.get_text() for x in
                                   ('APPENDIX','CONCLUSION','Fig.','TABLE ')))
    assert bottom>400 or bibliography_tail,(i+1,bottom)
    page_rects.append({'page':i+1,'content_bottom':bottom,
                       'natural_bibliography_tail':bibliography_tail and bottom<=400})

first_mentions={}
for n in range(1,8):
    cap=positions[f'Fig. {n}.']
    prior=[]
    for i,page in enumerate(doc):
        for r in page.search_for(f'Fig. {n}'):
            if i+1<cap['page'] or (i+1==cap['page'] and (r.x1<cap['bbox'][0] or r.y1<cap['bbox'][1])):
                prior.append(i+1)
    assert prior,n
    first_mentions[f'Fig. {n}']=min(prior)
for n,roman in ((1,'I'),(2,'II')):
    label='TABLE '+roman;cap=positions[label];prior=[]
    for i,page in enumerate(doc):
        for r in page.search_for('Table '+roman):
            if i+1<cap['page'] or (i+1==cap['page'] and (r.x1<cap['bbox'][0] or r.y1<cap['bbox'][1])):
                prior.append(i+1)
    assert prior,label
    first_mentions[label]=min(prior)
conclusion=positions['VI. CONCLUSION']
for label in [f'Fig. {n}.' for n in range(1,8)]+['TABLE I','TABLE II']:
    p=positions[label]
    assert p['page']<conclusion['page'] or (p['page']==conclusion['page'] and p['bbox'][3]<conclusion['bbox'][1]),label
ackpage=doc[positions['ACKNOWLEDGMENT']['page']-1].get_text()
assert all(t in ackpage for t in ('OpenAI Codex','ChatGPT','full responsibility'))
log=(R/'main.log').read_text(errors='replace')
for bad in ('Overfull','There were undefined','undefined references','multiply defined'):
    assert bad not in log,bad
fonts=subprocess.check_output(['pdffonts',str(R/'main.pdf')],text=True).splitlines()[2:]
assert all(line.split()[-5]=='yes' for line in fonts if line.strip())
assert not any(re.search('CJK|SimSun|SimHei|MS-Mincho|NotoSansCJK',line,re.I) for line in fonts)
result={'status':'pass','pages':len(doc),'separate_supplement':False,
        'abstract_words':len(abstract.split()),'numbered_main_sections':sections[:6],
        'appendices':sections[6:],'main_figures':7,'main_tables':2,
        'frozen_source_files_checked':len(source_record['files']),
        'preserved_scientific_files_checked':scientific,'figure_assets_checked':assets,
        'printed_Bernstein_max_error':max_printed_error,'confirmed_AI_text_unchanged':True,
        'main_pdf_sha256':hashlib.sha256((R/'main.pdf').read_bytes()).hexdigest(),
        'main_tex_sha256':hashlib.sha256((R/'main.tex').read_bytes()).hexdigest(),
        'fonts_embedded':True,'clean_latex_log':True,'first_mentions':first_mentions,
        'positions':positions,'page_geometry':page_rects}
(R/'data/integrated_final_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('PASS: integrated structure, exact printed primitives, 202 immutable source files, preserved science/figures, AI text, first citations and final layout')
