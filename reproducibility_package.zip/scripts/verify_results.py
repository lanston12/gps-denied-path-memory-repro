"""Independent CSV consistency checks for the reported estimator quantities."""
from pathlib import Path
import numpy as np
import pandas as pd

D = Path(__file__).resolve().parents[1] / "data"
h = pd.read_csv(D / "hop_parameters.csv")
p = pd.read_csv(D / "gamma_products.csv")
c = pd.read_csv(D / "coverage_results.csv")
s = pd.read_csv(D / "scaling_results.csv")
o = pd.read_csv(D / "outage_results.csv")

assert len(h) == 3120 and len(p) == 62160
assert np.allclose(h.gamma, h.L_screened / (1 + 1e-6 * h.mu_eff),
                   rtol=1e-12, atol=1e-12)
assert (h.actual_d_norm_1pm <= h.dbar_1pm + 1e-12).all()
assert c.pointwise_covered.all() and c.coeff_covered.all()
assert np.all(c.position_error_m <= c.screened_position_radius_m + 1e-12)
for (regime, N, seed), group in h.groupby(["regime", "N", "seed"]):
    group = group.sort_values("vehicle_index")
    sub = p[(p.regime == regime) & (p.N == N) & (p.seed == seed)]
    assert len(sub) == N * (N + 1) // 2
    gamma = group.gamma.to_numpy()
    calculated = np.array([np.prod(gamma[int(j):int(i)])
                           for j, i in zip(sub.start_index, sub.end_index)])
    assert np.allclose(calculated, sub["product"].to_numpy(),
                       rtol=1e-12, atol=1e-14)
    rows = s[(s.regime == regime) & (s.N == N) & (s.seed == seed)]
    rows = rows.sort_values("vehicle_index")
    assert np.allclose(rows.screened_coeff_radius_1pm,
                       rows.inherited_bound_1pm + rows.additive_bound_1pm,
                       rtol=1e-10, atol=1e-12)
assert o.groupby("mode").size().to_dict() == {
    "age_valid_memory": 76, "bounded_local_inference": 7,
    "unavailable_preview": 18}
print("PASS: hop equations, 62,160 interval products, radius decomposition, "
      "sampled coverage, outage modes")
