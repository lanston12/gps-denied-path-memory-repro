"""Check TVT-only numerical claims and document invariants."""
from pathlib import Path
import re
import json
import subprocess
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'main.tex').read_text(encoding='utf-8')
supp='' # Necessary former supplement material is now in main.tex.
assert 'Bernstein/B-spline' not in main+supp
assert 'CarSim' not in main+supp
assert '95% Gaussian' not in main+supp
assert '(S_iE_a-E_bT_i)x_{i-1}' in main
assert 'r_{{\\rm proj},i}' in main
for tag in ('\\section{Results and Discussion}','\\section{Conclusion}','\\label{tab:related}','\\label{tab:parameters}'):
 assert tag in main,tag
for name in ('fig3_model_gate_v3.pdf','fig4_physical_gain_v3.pdf','fig5_cross_model_tvt.pdf','fig6_admissible_preview_v3.pdf','fig7_integrated_matlab_v3.pdf'):
 assert (ROOT/'figures'/name).is_file(),name
refs=set(re.findall(r'@\w+\{([^,]+),',(ROOT/'references.bib').read_text(encoding='utf-8')))
for cite in re.findall(r'\\cite\{([^}]+)\}',main):
 for k in cite.split(','):assert k in refs,k
for label in re.findall(r'\\label\{([^}]+)\}',main):
 assert main.count('\\label{'+label+'}')==1,label
for label in re.findall(r'\\ref\{([^}]+)\}',main):
 assert '\\label{'+label+'}' in main,label
for fig in ('architecture','frames','modelgate','gainaudit','switch','preview','dynamics'):
 assert main.index('Fig.~\\ref{fig:'+fig+'}')<main.index('\\label{fig:'+fig+'}'),fig
x=pd.read_csv(ROOT/'data/tvt_primary30_preview_results.csv')
f=x[(x.N==20)&(x.visible_m==15)&(x.epsilon_ref_m==.2)&(x.vehicle_index==20)&(x.method=='fused')]
l=x[(x.N==20)&(x.visible_m==15)&(x.epsilon_ref_m==.2)&(x.vehicle_index==20)&(x.method=='local_only')]
assert len(f)==len(l)==30
assert np.isclose(f.admissible_preview_m.mean(),23.016666666666666)
assert np.isclose(f.set_index('seed').admissible_preview_m.sub(l.set_index('seed').admissible_preview_m).mean(),8.016666666666666)
assert np.isclose(f[f.seed<4].nominal_preview_m.mean(),26.25)
assert np.isclose(f[f.seed<4].admissible_preview_m.mean(),22.75)
y=pd.read_csv(ROOT/'data/tvt_D3_D4_paired_results.csv')
assert len(y)==60 and (y.groupby(['scenario','seed']).method.nunique()==3).all()
for scenario,expected in [('D3_v2v_burst',-.037810),('D4_heterogeneous',-.083438)]:
 a=y[y.scenario==scenario].pivot(index='seed',columns='method',values='lateral_rmse_m')
 assert np.isclose((a.admissible_fusion-a.nominal_fusion).mean(),expected,atol=1e-6)
summary=pd.read_csv(ROOT/'data/tvt_seed_summary.csv')
primary=summary[(summary.study=='estimator')&(summary.method=='fused')&(summary.metric=='admissible_preview_m')].iloc[0]
assert np.isclose(primary.ci95_low,21.3321,atol=5e-5)
assert np.isclose(primary.ci95_high,24.7013,atol=5e-5)
metadata=json.loads((ROOT/'data/tvt_reference_metadata.json').read_text(encoding='utf-8'))
assert len(metadata)==18 and all('error' not in v for v in metadata.values())
pdf_checks={}
for name,cap in [('main.pdf',14)]:
 info=subprocess.check_output(['pdfinfo',str(ROOT/name)],text=True)
 pages=int(re.search(r'^Pages:\s+(\d+)',info,re.M).group(1));assert 1<=pages<=cap,(name,pages)
 fonts=subprocess.check_output(['pdffonts',str(ROOT/name)],text=True).splitlines()[2:]
 assert all(line.split()[-5]=='yes' for line in fonts if line.strip()),(name,'unembedded font')
 pdf_checks[name]={'pages':pages,'all_fonts_embedded':True}
 for bad in ('Overfull \\hbox','undefined references','Citation `','There were undefined references'):
  assert bad not in (ROOT/name.replace('.pdf','.log')).read_text(errors='replace'),(name,bad)
(ROOT/'data/tvt_final_checks.json').write_text(json.dumps({'status':'pass','estimator_seeds':30,'paired_dynamic_records':60,'verified_DOI_records':18,'pdfs':pdf_checks},indent=2),encoding='utf-8')
print('PASS: 30 estimator seeds; 60 paired D3/D4 records; 18 DOI records; labels, citations, figures, embedded fonts, clean PDFs, TVT page cap')
