"""Cross-check the released v2 numerical claims from CSV artifacts."""
from pathlib import Path
import numpy as np
import pandas as pd
D=Path(__file__).resolve().parents[1]/"data"
b=pd.read_csv(D/"basis_rescaling.csv")
assert b.absolute_invariance_error.max()<1e-10
assert (abs(b.physical_gain_original-b.physical_gain_consistent)<1e-10).all()
scale=pd.read_csv(D/"metric_scale_sensitivity.csv")
assert len(scale)==27 and scale.all_hops_contractive.all()
m=pd.read_csv(D/"adaptive_model_bank.csv")
assert (m.accepted==(m.model_pass&m.information_pass&m.converged)).all()
s=pd.read_csv(D/"adaptive_model_selection.csv")
assert len(s)==11 and s.accepted.all()
n=pd.read_csv(D/"nonlinear_set_results.csv")
assert n.true_inside_outer.all()
assert (n.nonlinear_union_path_screen_m>=n.actual_end_error_m).all()
pn=pd.read_csv(D/"partial_nonlinear_set.csv")
assert (pn.nonlinear_union_far_screen_m>=pn.actual_far_error_m).all()
f=pd.read_csv(D/"set_fusion_results.csv")
assert (f.status=="valid").all()
p=pd.read_csv(D/"physical_gamma_products.csv")
x=pd.read_csv(D/"partial_visibility_results.csv")
assert len(p)==4*16*20*21//2
for (condition,seed),g in p.groupby(["condition","seed"]):
    vis=float(g.visible_m.iloc[0]);weight=float(g.p.iloc[0])
    hops=x[(x.visible_m==vis)&(x.p==weight)&(x.method=="fused")&
           (x.seed==seed)].sort_values("vehicle_index").gamma_phys.to_numpy()
    products=np.array([np.prod(hops[int(j):int(i)])
                       for j,i in zip(g.start_index,g.end_index)])
    assert np.allclose(products,g["product"].to_numpy(),rtol=1e-11,atol=1e-12)
v=pd.read_csv(D/"matlab_dynamic_results.csv")
assert len(v)==16 and set([5,10,20])<=set(v.N)
assert v[(v.scenario=="D5_low_friction")&
         (v.uncertainty_aware==0)].validity_terminated.all()
print("PASS: metric invariance, model gates, nonlinear outer screens, "
      "13,440 physical interval products, and MATLAB case records")
