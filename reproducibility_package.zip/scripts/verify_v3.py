"""Recompute final interval, consistency, support and dynamic record checks."""
from pathlib import Path
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parents[1];D=R/'data'

def verify():
    required=('main.tex','main.pdf','references.bib',
       'supplement_integration_audit.md','section_consolidation_audit.md',
       'defensive_language_audit.md','appendix_content_audit.md',
       'symbol_acronym_audit.md','cross_reference_float_audit.md',
       'submission_audit.md','submission_readiness.md','revision_log.md','REPRODUCE.md')
    assert all((R/f).exists() for f in required)

    c=pd.read_csv(D/'cross_model_transport_audit.csv')
    iv=pd.read_csv(D/'cross_model_interval_products.csv')
    assert len(c)==99 and set(c.source)=={'M1','M2','M3','M4'}
    assert c.basis_invariance_error.max()<1e-10
    for row in iv.itertuples():
        g=c[(c.sequence==row.sequence)&(c.p==row.p)].sort_values('hop')
        part=g[(g.hop>=row.start_hop)&(g.hop<=row.end_hop)]
        raw=float(part.physical_gain.iloc[0]);gated=raw if part.transport_accepted.iloc[0] else 0.
        for k in range(1,len(part)):
            factor=part.physical_gain.iloc[k]*part.connector_from_previous.iloc[k]
            raw*=factor
            gated*=factor if part.transport_accepted.iloc[k] else 0.
        assert abs(raw-row.raw_product)<1e-9*max(1,abs(raw))
        assert abs(gated-row.gated_product)<1e-9*max(1,abs(gated))
    realized=c[(c.sequence=='realized')&(c.p==1)]
    assert int(realized.transport_accepted.sum())==6

    py=pd.read_csv(D/'python_estimator_outputs.csv')
    ml=pd.read_csv(D/'matlab_estimator_outputs.csv')
    assert len(py)==len(ml)==21
    assert set(py.model)=={'M1','M2','M3','M4'}
    for col in ('model','model_valid','age_valid'):
        assert (py[col].fillna('')==ml[col].fillna('')).all(),col
    for col in ('nominal_m','admissible_m','mu','projection_rms_m',
                'offset_m','heading','c1','c2','c3','c4'):
        a,b=py[col].to_numpy(),ml[col].to_numpy()
        assert np.nanmax(np.abs(a-b))<1e-10,col

    p=pd.read_csv(D/'admissible_preview_results.csv')
    ivp=pd.read_csv(D/'admissible_all_interval_products.csv')
    assert len(p)==6720 and len(ivp)==13440
    assert set(p.N)=={5,10,20} and set(p.visible_m)=={8.,12.,15.,30.}
    assert set(p.method)=={'local_only','v2v_only','pose_v2v','fused'}
    assert p[p.nominal_preview_m<30].far_30m_error_m.isna().all()
    assert (p.admissible_preview_m<=p.nominal_preview_m+1e-10).all()
    endpoint=p[(p.N==20)&(p.vehicle_index==20)&
               (p.visible_m==15)&(p.epsilon_ref_m==.2)&(p.method=='fused')]
    assert len(endpoint)==4
    assert abs(endpoint.nominal_preview_m.mean()-26.25)<1e-12
    assert abs(endpoint.admissible_preview_m.mean()-22.75)<1e-12
    for (N,vis,seed,eps),group in p[p.method=='fused'].groupby(
            ['N','visible_m','seed','epsilon_ref_m']):
        gain=group.sort_values('vehicle_index').physical_gain.to_numpy()
        records=ivp[(ivp.N==N)&(ivp.visible_m==vis)&
                    (ivp.seed==seed)&(ivp.epsilon_ref_m==eps)]
        for row in records.itertuples():
            assert abs(np.prod(gain[row.start-1:row.end])-row.product)<1e-10

    dyn=pd.read_csv(D/'integrated_dynamic_results.csv')
    assert len(dyn)==21
    for _,g in dyn.groupby(['scenario','N']):
        assert set(g.method)=={'local_only','nominal_fusion','admissible_fusion'}
    assert dyn[dyn.scenario=='D5_low_friction'].validity_terminated.all()
    assert (dyn.computation_s>0).all()
    assert not any('carsim' in f.name.lower() for f in D.glob('*results*.csv'))
    manuscript=(R/'main.tex').read_text(encoding='utf-8')
    assert 'last follower' in manuscript and '26.25 m' in manuscript
    assert '22.75 m' in manuscript
    for forbidden in ('NSFC project','companion manuscript','GO-B','v2_practical'):
        assert forbidden not in manuscript
    print('PASS: rectangular transport, norm connectors, interval products, '
          '21 Python/MATLAB records, 13,440 preview products, and 21 MATLAB cases')

if __name__=='__main__':verify()
