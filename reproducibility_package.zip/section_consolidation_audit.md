# Section consolidation audit

| Former location | Integrated location | Treatment |
|---|---|---|
| I Introduction | I Introduction | Same problem/contributions; concise positive abstract scope. |
| II Related Work / Problem | II Related Work / Problem | Add follower/hop indexing; keep factual related-work comparison. |
| III path reconstruction | III-A/B | Local memory, body-point canonicalization, distinct tangent angle, finite gate. |
| IV propagation | III-C | Physical interface, rectangular map, connector, theorem and three-hop metric start. |
| V preview | III-D | Formal longest-valid-prefix and quality equations, age/support/model rules, fallback. |
| VI methodology | IV-A/B/C | Baselines, nonlinear scenarios, paired metrics/seed designs. |
| VII Results + VIII Discussion | V-A/B/C/D | Four result subsections; interpretation beside evidence; one limitations paragraph. |
| IX Conclusion | VI Conclusion | Three contributions, two strongest numerical observations, future work. |
| Necessary former supplement | Appendices A/B | Exact primitive/metric recipe and transport coordinate/interval details. |

Only six numbered top-level sections remain. Acknowledgment and Data/Code Availability are unnumbered administrative sections. Appendix C is unnecessary: its potential essential scenario/seed material fits in IV and Table II. Table III was removed, not relabeled. Seven main figures and two tables remain.
