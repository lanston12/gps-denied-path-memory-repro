function run_multi_vehicle()
% Nonlinear multi-vehicle MATLAB study. This is diagnostic, not a certified
% tube-MPC demonstration. CarSim is not called.
outdir = fullfile(fileparts(fileparts(mfilename('fullpath'))),'data');
cases = {
    'D1_curve_occlusion',5,'local_only',0;
    'D1_curve_occlusion',5,'v2v_only',0;
    'D1_curve_occlusion',5,'fused',0;
    'D1_curve_occlusion',5,'fused',1;
    'D1_curve_occlusion',10,'fused',0;
    'D1_curve_occlusion',10,'fused',1;
    'D1_curve_occlusion',20,'fused',0;
    'D1_curve_occlusion',20,'fused',1;
    'D2_s_curve',10,'fused',0;
    'D2_s_curve',10,'fused',1;
    'D3_v2v_burst',10,'fused',0;
    'D3_v2v_burst',10,'fused',1;
    'D4_heterogeneous',20,'fused',0;
    'D4_heterogeneous',20,'fused',1;
    'D5_low_friction',5,'fused',0;
    'D5_low_friction',5,'fused',1};
rows = cell(size(cases,1),1);
for k=1:size(cases,1)
    rows{k}=one_case(cases{k,1},cases{k,2},cases{k,3},logical(cases{k,4}));
    fprintf('%d/%d %s N=%d %s aware=%d margin=%.3f\n',k,size(cases,1), ...
        cases{k,1},cases{k,2},cases{k,3},cases{k,4},rows{k}.min_body_margin_m);
end
T=struct2table([rows{:}]);
writetable(T,fullfile(outdir,'matlab_dynamic_results.csv'));
end

function result=one_case(scenario,N,method,aware)
rng(5401);  % paired sensor draws in each method; plant states may diverge.
dt=.02; Tstop=20; steps=round(Tstop/dt);
gap=15; LdGoal=25; localVisible=15;
if strcmp(scenario,'D5_low_friction')
    mu=.35; vnom=18;
else
    mu=.85; vnom=18;
end
% State rows: X,Y,psi,vy,r,delta,vx.
state=zeros(N,7);
for i=1:N
    state(i,1)=-i*gap;
    state(i,2)=road_y(state(i,1),scenario);
    state(i,3)=atan(road_slope(state(i,1),scenario));
    state(i,7)=vnom;
end
mass=1450+45*(1:N)'; Iz=2400+100*(1:N)';
lf=1.15+.012*(1:N)'; lr=1.35+.009*(1:N)';
Cf=65000+500*(1:N)'; Cr=72000+450*(1:N)';
Tdelta=.14+.002*(1:N)';
lastRxPoints=cell(N,1);lastRxPose=cell(N,1);
lastAge=inf(N,1);
minMargin=inf;maxEy=0;maxBeta=0;maxYaw=0;maxAy=0;
satCount=0;corridorCount=0;slipCount=0;previewSum=0;speedSum=0;
unavailableCount=0;timeRecords=zeros(steps,5);
invalid=false;invalidReason="";executedSteps=steps;
for step=1:steps
    t=(step-1)*dt;
    visible=localVisible;
    if strcmp(scenario,'D1_curve_occlusion') && t>=7 && t<13
        visible=8;
    end
    comm=true;
    if strcmp(scenario,'D3_v2v_burst') && t>=5 && t<8.2
        comm=false;
    end
    % Virtual leader: road-following source with only locally seen points.
    leaderX=vnom*t;
    leaderY=road_y(leaderX,scenario);
    leaderPsi=atan(road_slope(leaderX,scenario));
    predPose=[leaderX,leaderY,leaderPsi];
    [leaderPts,~]=sensor_points(predPose,visible,scenario);
    leadPoly=polyfit(leaderPts(:,1),leaderPts(:,2),3);
    predMem=sample_poly(leadPoly,visible);
    predValid=visible;
    pathPoly=cell(N,1);valid=zeros(N,1);unc=zeros(N,1);
    for i=1:N
        pose=state(i,1:3);
        [localPts,pointNoise]=sensor_points(pose,visible,scenario);
        haveRemote=false;
        if ~strcmp(method,'local_only') && comm
            relPts=transform_points(predMem,predPose,pose);
            relPts=relPts+0.01*randn(size(relPts));
            remoteMax=max(relPts(:,1));
            haveRemote=true;
            lastAge(i)=0;
            lastRxPoints{i}=relPts;lastRxPose{i}=pose;
        elseif ~strcmp(method,'local_only') && lastAge(i)+dt<=.8 && ...
                ~isempty(lastRxPoints{i}) && strcmp(scenario,'D3_v2v_burst')
            % Locally propagated last accepted polynomial; finite age only.
            relPts=transform_points(lastRxPoints{i},lastRxPose{i},pose);
            remoteMax=max(relPts(:,1));
            haveRemote=true;
            lastAge(i)=lastAge(i)+dt;
        else
            lastAge(i)=lastAge(i)+dt;
        end
        if strcmp(method,'v2v_only') && haveRemote
            fitPts=relPts;
        elseif haveRemote && ~strcmp(method,'local_only')
            fitPts=[localPts;relPts];
        else
            fitPts=localPts;
        end
        % Same cubic least-squares path estimator and same controller.
        degree=min(3,size(fitPts,1)-1);
        poly=polyfit(fitPts(:,1),fitPts(:,2),degree);
        resid=fitPts(:,2)-polyval(poly,fitPts(:,1));
        if haveRemote
            horizon=min(30,max(visible,remoteMax));
        else
            horizon=visible;
        end
        if strcmp(method,'v2v_only') && ~haveRemote
            % Explicitly mark no remote preview; local fallback is
            % performance-only and does not masquerade as V2V.
            horizon=visible;
        end
        pathPoly{i}=poly;valid(i)=max(0,horizon);
        unc(i)=.10+4*sqrt(mean(resid.^2))+.05*min(lastAge(i),.8);
        predMem=sample_poly(poly,horizon);
        predValid=horizon; %#ok<NASGU>
        predPose=pose;
    end
    if aware
        % Transparent uncertainty-aware speed/preview heuristic. Its
        % uncertainty number is empirical, not a deterministic tube.
        commonTarget=vnom*max(.55,min(1,(.9-max(unc))/.9));
    else
        commonTarget=vnom;
    end
    for i=1:N
        L=lf(i)+lr(i);
        look=min(LdGoal,valid(i));
        ytarget=polyval(pathPoly{i},look);
        deltaCmd=atan2(2*L*ytarget,look^2)-.12*state(i,5);
        if abs(deltaCmd)>.45, satCount=satCount+1;end
        deltaCmd=max(-.45,min(.45,deltaCmd));
        dRate=max(-.5,min(.5,(deltaCmd-state(i,6))/Tdelta(i)));
        vx=max(3,state(i,7));vy=state(i,4);r=state(i,5);
        af=state(i,6)-atan2(vy+lf(i)*r,vx);
        ar=-atan2(vy-lr(i)*r,vx);
        Fzf=mass(i)*9.81*lr(i)/L; Fzr=mass(i)*9.81*lf(i)/L;
        Fyf=mu*Fzf*tanh(Cf(i)*af/(mu*Fzf));
        Fyr=mu*Fzr*tanh(Cr(i)*ar/(mu*Fzr));
        vyDot=(Fyf+Fyr)/mass(i)-vx*r;
        rDot=(lf(i)*Fyf-lr(i)*Fyr)/Iz(i);
        psi=state(i,3);
        state(i,1)=state(i,1)+dt*(vx*cos(psi)-vy*sin(psi));
        state(i,2)=state(i,2)+dt*(vx*sin(psi)+vy*cos(psi));
        state(i,3)=state(i,3)+dt*r;
        state(i,4)=state(i,4)+dt*vyDot;
        state(i,5)=state(i,5)+dt*rDot;
        state(i,6)=max(-.45,min(.45,state(i,6)+dt*dRate));
        state(i,7)=max(3,state(i,7)+dt*max(-2,min(2,(commonTarget-vx))));
        roadPsi=atan(road_slope(state(i,1),scenario));
        eY=(state(i,2)-road_y(state(i,1),scenario))*cos(roadPsi);
        ePsi=atan2(sin(state(i,3)-roadPsi),cos(state(i,3)-roadPsi));
        margin=1.8-(abs(eY)+.9+2.2*abs(sin(ePsi)));
        minMargin=min(minMargin,margin);
        maxEy=max(maxEy,abs(eY));maxBeta=max(maxBeta,abs(atan2(state(i,4),state(i,7))));
        maxYaw=max(maxYaw,abs(state(i,5)));
        maxAy=max(maxAy,abs(vyDot+vx*r));
        corridorCount=corridorCount+(margin<0);
        slipCount=slipCount+(abs(atan2(state(i,4),state(i,7)))>.08);
        previewSum=previewSum+valid(i);speedSum=speedSum+state(i,7);
        unavailableCount=unavailableCount+(valid(i)<LdGoal);
    end
    timeRecords(step,:)=[t,min(valid),mean(valid),minMargin,mean(state(:,7))];
    if maxBeta>.3 || maxEy>5
        invalid=true;invalidReason="large sideslip or lateral departure";
        executedSteps=step;
        break
    end
end
result=struct('scenario',scenario,'N',N,'method',method,'uncertainty_aware',aware, ...
    'min_body_margin_m',minMargin,'max_lateral_error_m',maxEy, ...
    'max_sideslip_rad',maxBeta,'max_yaw_rate_radps',maxYaw, ...
    'max_lateral_accel_mps2',maxAy, ...
    'corridor_violation_fraction',corridorCount/(executedSteps*N), ...
    'sideslip_violation_fraction',slipCount/(executedSteps*N), ...
    'steering_saturation_fraction',satCount/(executedSteps*N), ...
    'mean_valid_preview_m',previewSum/(executedSteps*N), ...
    'preview_below_goal_fraction',unavailableCount/(executedSteps*N), ...
    'mean_speed_mps',speedSum/(executedSteps*N), ...
    'validity_terminated',invalid,'termination_time_s',executedSteps*dt, ...
    'termination_reason',invalidReason);
if strcmp(scenario,'D3_v2v_burst') && N==10 && strcmp(method,'fused')
    outdir=fullfile(fileparts(fileparts(mfilename('fullpath'))),'data');
    suffix='nominal';if aware,suffix='aware';end
    writematrix(timeRecords(1:executedSteps,:), ...
        fullfile(outdir,['matlab_D3_trace_' suffix '.csv']));
end
end

function [pts,noise]=sensor_points(pose,visible,scenario)
s=linspace(0,visible,13)';
world=[pose(1)+s,road_y(pose(1)+s,scenario)];
c=cos(pose(3));q=sin(pose(3));
R=[c q;-q c];
pts=(world-pose(1:2))*R';
noise=.01*randn(size(pts));
pts=pts+noise;
end

function points=sample_poly(poly,horizon)
x=linspace(0,horizon,13)';
points=[x,polyval(poly,x)];
end

function points=transform_points(predPts,predPose,receiverPose)
cp=cos(predPose(3));sp=sin(predPose(3));
Rp=[cp -sp;sp cp];
world=predPts*Rp'+predPose(1:2);
cr=cos(receiverPose(3));sr=sin(receiverPose(3));
Rr=[cr sr;-sr cr];
points=(world-receiverPose(1:2))*Rr';
end

function y=road_y(x,scenario)
switch scenario
    case 'D1_curve_occlusion'
        y=2*sin(x/50)+.4*sin(x/12);
    case 'D2_s_curve'
        y=1.75*tanh((x-20)/12)-1.75*tanh((x-95)/12);
    case 'D3_v2v_burst'
        y=2*sin(x/40);
    case 'D4_heterogeneous'
        y=3*sin(x/35)+.6*sin(x/15);
    case 'D5_low_friction'
        y=5*sin(x/18);
end
end

function slope=road_slope(x,scenario)
dx=.01;
slope=(road_y(x+dx,scenario)-road_y(x-dx,scenario))/(2*dx);
end
