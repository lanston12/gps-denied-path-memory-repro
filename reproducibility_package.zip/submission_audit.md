# Integrated submission audit

## Scientific and technical checklist

- [x] One self-contained paper: framework III-A/D, theorem III-C, experiments IV, results V, two technical appendices.
- [x] Body yaw and path-tangent angle separated; follower/hop indexing stated.
- [x] Main retains input/output metrics, connector, three-hop input start, preceding-output factor, represented bound and separate physical residuals.
- [x] Exact basis and cubic Bernstein/window-dependent primitives accessible in A; coordinate and interval detail in B.
- [x] Formal L_adm and pointwise engineering index retain k_q, validity, age/support and fallback rules.
- [x] D1-D5 and N=5/10/20 understandable from IV/Table II; no new simulation or high-fidelity result added.
- [x] Primary 30-seed evidence distinguished from four-seed Fig. 6; paired D3/D4 repeats retain their conditional interpretation.
- [x] Redundant Table III removed; five former supplementary tables external; no supplementary PDF generated.
- [x] Confirmed AI acknowledgment retained exactly; scientific source and numerical records preserved.
- [x] All four current verifiers pass; all 11 pages rendered/visually reviewed. 202 source hashes and 77 inherited code/CSV hashes match; figures and bibliography remain byte-identical. Printed Bernstein primitive error is at most 2.85e-14. Fonts embedded, references resolved, no overfull/clipping; Results finish before Conclusion.

## Administrative checklist

- [ ] All author names/order and affiliations approved and supplied.
- [ ] Corresponding author/email, ORCIDs and postal details supplied.
- [ ] Funding and grant statement supplied or truthful no-funding statement confirmed.
- [ ] Conflicts/declarations/prior-publication overlap supplied as required.
- [ ] Authors personally verify scientific content and complete AI-use scope.
- [ ] TVT-specific acceptability of the ChatGPT-generated Fig. 1 confirmed by authors; disclosure alone is not a policy acceptance determination.

The existing author placeholder is retained. No authorship, funding, declarations, public code URL or portal submission has been invented. The current TVT initial regular-paper cap is 14 pages including references/biographies; the integrated PDF is below it.

SCIENTIFIC STATUS: READY-TVT

Reference update (2026-09-29): all 22 records rechecked; reference 19's identical-author dash replaced by explicit author names through IEEEtran style control. No scientific bibliography fields or numbering changed; the PDF remains 11 pages. Current reference, font and layout checks pass. The four-verifier/source-inventory checklist above records consolidation-stage results. This time the two stored-data verifiers pass, while the two external-source verifiers cannot complete because the earlier frozen directory is absent. Current Fig. 1 had already been updated from the root image before this reference task, so its byte-identity statement above also belongs to the consolidation record. See `reference_recheck_20260929.md` for current provenance and PDF hashes.

PORTAL STATUS: ADMINISTRATIVE-BLOCKER
