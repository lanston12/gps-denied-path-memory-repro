# Symbol and acronym audit

| Object | Definition/use |
|---|---|
| i, N, hop i | II-C explicitly indexes followers 1,...,N; hop i is i-1 to i. |
| body yaw psi_i | III-A rigid-point conversion; distinct from path tangent under sideslip. |
| theta_i(s), b_i | III-B local path-tangent angle and its initial nuisance angle; small-angle normal graph uses theta, never body yaw. |
| Psi_(m,W) | Capital heading primitive, not body yaw. |
| T_(i<-i-1), T_i | Fig. 2 pose-registration transform versus III-C coefficient collocation; distinct indexed roles. |
| Q_(i-1,in), Q_(i,out), Q_(i,local) | III-C source comparison, output comparison and local-information metric. |
| c_i, G_(j:i), tilde G | Connector, input-start interval, preceding-output-start interval. Three-hop example in main; four-hop in B. |
| r_proj full field / r_proj,rms | Offline physical field versus online lateral point-fit RMS, explicitly separated in III-C/D. |
| J_i, mu_i, k_q | Design conditioning, physical-normalized minimum information, fixed engineering quality scale. |

GPS and V2V are expanded in Introduction; SE(2) in III-A; RMS in III-D; RMSE in IV-C; LiDAR in V-D. These definitions are prose, not dependent on a caption. Title/keywords use standard abbreviations; no symbol psi is reused for the normal-graph tangent angle.
